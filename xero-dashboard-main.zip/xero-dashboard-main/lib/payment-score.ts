/**
 * Customer payment-behavior score, computed from paid invoice history.
 * Output: average days late + a 0-10 score + a category label.
 */

export type PaymentLabel =
  | "great"
  | "good"
  | "average"
  | "slow"
  | "bad"
  | "unknown";

export interface ContactScore {
  contactID: string;
  avgDaysLate: number;
  onTimeRate: number;
  invoicesPaid: number;
  score: number;
  label: PaymentLabel;
}

interface InvoiceForScore {
  contactID?: string;
  dueDate?: string | Date | null;
  fullyPaidOnDate?: string | Date | null;
}

function dateOf(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  const d = value instanceof Date ? value : new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

export function computeContactScores(
  paidInvoices: InvoiceForScore[]
): Map<string, ContactScore> {
  const acc = new Map<
    string,
    { lags: number[]; total: number; onTime: number }
  >();

  for (const inv of paidInvoices) {
    if (!inv.contactID) continue;
    const due = dateOf(inv.dueDate);
    const paid = dateOf(inv.fullyPaidOnDate);
    if (!due || !paid) continue;
    const lag = daysBetween(due, paid);
    const cur = acc.get(inv.contactID) || { lags: [], total: 0, onTime: 0 };
    cur.lags.push(lag);
    cur.total += 1;
    if (lag <= 0) cur.onTime += 1;
    acc.set(inv.contactID, cur);
  }

  const out = new Map<string, ContactScore>();
  for (const [contactID, c] of acc) {
    const avgDaysLate = c.lags.reduce((s, x) => s + x, 0) / c.lags.length;
    const onTimeRate = c.onTime / c.total;
    // 0 days late = 10, ~30 days late ≈ 2-3, never goes below 0.
    let score = 10 - Math.max(0, avgDaysLate / 4);
    score = Math.max(0, Math.min(10, score));

    let label: PaymentLabel;
    if (c.total < 2) label = "unknown";
    else if (avgDaysLate <= 0) label = "great";
    else if (avgDaysLate <= 7) label = "good";
    else if (avgDaysLate <= 14) label = "average";
    else if (avgDaysLate <= 30) label = "slow";
    else label = "bad";

    out.set(contactID, {
      contactID,
      avgDaysLate,
      onTimeRate,
      invoicesPaid: c.total,
      score,
      label,
    });
  }
  return out;
}
