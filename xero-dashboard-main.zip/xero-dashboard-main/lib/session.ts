import { cookies } from "next/headers";
import { getIronSession, type SessionOptions } from "iron-session";

export interface SessionData {
  access_token?: string;
  refresh_token?: string;
  expires_at?: number;
  tenantId?: string;
  tenantName?: string;
  tenants?: Array<{ id: string; name: string }>;
  baseCurrency?: string;
  countryCode?: string;
  oauthState?: string;
}

const password = process.env.SESSION_SECRET;
if (!password || password.length < 32) {
  // iron-session requires >= 32 chars; throw early in dev so the misconfiguration is obvious.
  if (process.env.NODE_ENV !== "production") {
    console.warn(
      "[session] SESSION_SECRET is missing or shorter than 32 chars. Set it in .env.local."
    );
  }
}

export const sessionOptions: SessionOptions = {
  password: password || "dev_only_replace_me_with_32+_random_chars__",
  cookieName: "xero_dashboard",
  cookieOptions: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 8,
  },
};

export async function getSession() {
  const store = await cookies();
  return getIronSession<SessionData>(store, sessionOptions);
}
