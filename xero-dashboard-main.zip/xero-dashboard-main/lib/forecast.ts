/**
 * Cash flow forecast — pure computation on Xero data.
 *
 * Approach:
 * 1. For each contact with paid-invoice history, compute average payment lag
 *    (days between dueDate and fullyPaidOnDate). A positive number means
 *    they tend to pay late; negative = early.
 * 2. For each unpaid receivable, predict its arrival as
 *    `dueDate + contact-specific lag` (or global average if no history).
 * 3. For each unpaid bill, assume on-time payment at dueDate.
 * 4. Bucket inflows/outflows into weekly windows for the next N weeks and
 *    compute a running net cash balance.
 */

export interface CashflowBucket {
  weekStart: string; // YYYY-MM-DD
  weekLabel: string; // "Apr 28"
  inflow: number;
  outflow: number;
  netBalance: number;
}

interface DatedRecord {
  contactID?: string;
  dueDate?: string | Date | null;
  fullyPaidOnDate?: string | Date | null;
  amountDue?: number;
}

function dateOf(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  const d = value instanceof Date ? value : new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

export function computePaymentLags(paidInvoices: DatedRecord[]): {
  byContact: Map<string, number>;
  global: number;
} {
  const buckets = new Map<string, { sum: number; n: number }>();
  let globalSum = 0;
  let globalN = 0;
  for (const inv of paidInvoices) {
    const due = dateOf(inv.dueDate);
    const paid = dateOf(inv.fullyPaidOnDate);
    if (!due || !paid) continue;
    const lag = daysBetween(due, paid);
    if (inv.contactID) {
      const acc = buckets.get(inv.contactID) || { sum: 0, n: 0 };
      acc.sum += lag;
      acc.n += 1;
      buckets.set(inv.contactID, acc);
    }
    globalSum += lag;
    globalN += 1;
  }
  const result = new Map<string, number>();
  for (const [k, v] of buckets) {
    result.set(k, v.sum / v.n);
  }
  return { byContact: result, global: globalN > 0 ? globalSum / globalN : 0 };
}

export function buildCashflowForecast(input: {
  receivables: DatedRecord[];
  bills: DatedRecord[];
  paidInvoices: DatedRecord[];
  startingCash: number;
  weeks?: number;
}): CashflowBucket[] {
  const weeks = input.weeks ?? 8;
  const lags = computePaymentLags(input.paidInvoices);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const buckets: CashflowBucket[] = Array.from({ length: weeks }, (_, i) => {
    const start = new Date(today);
    start.setDate(today.getDate() + i * 7);
    return {
      weekStart: start.toISOString().slice(0, 10),
      weekLabel: start.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
      }),
      inflow: 0,
      outflow: 0,
      netBalance: 0,
    };
  });

  function findBucket(date: Date): number {
    if (date < today) return 0; // overdue → land in the current week
    const days = daysBetween(today, date);
    const idx = Math.floor(days / 7);
    return idx >= weeks ? -1 : idx;
  }

  for (const r of input.receivables) {
    if (!r.amountDue || r.amountDue <= 0) continue;
    const due = dateOf(r.dueDate);
    if (!due) continue;
    const lag =
      (r.contactID ? lags.byContact.get(r.contactID) : undefined) ??
      lags.global;
    const expected = new Date(due);
    expected.setDate(expected.getDate() + Math.round(lag));
    const idx = findBucket(expected);
    if (idx >= 0) buckets[idx].inflow += r.amountDue;
  }

  for (const b of input.bills) {
    if (!b.amountDue || b.amountDue <= 0) continue;
    const due = dateOf(b.dueDate);
    if (!due) continue;
    const idx = findBucket(due);
    if (idx >= 0) buckets[idx].outflow += b.amountDue;
  }

  let balance = input.startingCash;
  for (const b of buckets) {
    balance = balance + b.inflow - b.outflow;
    b.netBalance = balance;
  }

  return buckets;
}
