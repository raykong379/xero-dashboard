import { getXeroForRequest } from "@/lib/xero";
import { buildCashflowForecast, type CashflowBucket } from "@/lib/forecast";

export interface MonthBucket {
  month: string;
  revenue: number;
  expense: number;
}

export interface TopCustomer {
  name: string;
  total: number;
}

export interface AgedBucket {
  label: string;
  total: number;
  count: number;
}

export interface BankAccountBalance {
  accountID?: string;
  name: string;
  balance: number;
}

export interface RecentPayment {
  paymentID?: string;
  date?: string;
  amount: number;
  invoiceNumber?: string;
  contactName?: string;
  reference?: string;
  currencyCode?: string;
}

export interface DashboardData {
  baseCurrency: string;
  tenantName?: string;
  // Receivables (money in)
  outstandingTotal: number;
  outstandingCount: number;
  outstandingOverdueTotal: number;
  outstandingOverdueCount: number;
  // Payables (money out)
  billsTotal: number;
  billsCount: number;
  billsOverdueTotal: number;
  billsOverdueCount: number;
  // P&L
  thisMonthRevenue: number;
  thisMonthExpense: number;
  netProfitYtd: number;
  ytdRevenue: number;
  ytdExpense: number;
  // Other
  contactCount: number;
  bankBalances: BankAccountBalance[];
  cashInBank: number;
  monthly: MonthBucket[];
  topCustomers: TopCustomer[];
  agedBuckets: AgedBucket[];
  agedPayablesBuckets: AgedBucket[];
  recentPayments: RecentPayment[];
  cashflow: CashflowBucket[];
}

const MONTH_LABELS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

function monthKey(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(d: Date) {
  return `${MONTH_LABELS[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
}

function startOfMonthsAgo(months: number) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
}

function isoDate(d: Date) {
  return d.toISOString().slice(0, 10);
}

interface ReportCell {
  value?: string;
}
interface ReportRowLike {
  rowType?: string;
  title?: string;
  cells?: ReportCell[];
  rows?: ReportRowLike[];
}

/**
 * Walks a Xero report tree looking for the "Net Profit" summary row and
 * returns the rightmost numeric cell value. The row title can be "Net Profit"
 * or "Net Profit / (Loss)" depending on org locale, so we match leniently.
 */
function findNetProfit(rows: ReportRowLike[] | undefined): number {
  if (!rows) return 0;
  for (const r of rows) {
    if (r.rowType === "Section") {
      // Some orgs nest Net Profit inside the section.title rather than as a
      // SummaryRow. Walk both ways.
      const fromChildren = findNetProfit(r.rows);
      if (fromChildren !== 0) return fromChildren;
    }
    const title =
      r.title ||
      r.cells?.[0]?.value ||
      "";
    if (
      r.rowType === "SummaryRow" &&
      /net\s*profit/i.test(String(title))
    ) {
      const cells = r.cells || [];
      for (let i = cells.length - 1; i >= 1; i--) {
        const v = cells[i].value;
        if (v && !Number.isNaN(parseFloat(v))) {
          return parseFloat(v);
        }
      }
    }
  }
  return 0;
}

/**
 * Sums Income or Expense totals from a P&L report. We look for a row with the
 * matching title and grab its last numeric cell.
 */
function findReportTotal(
  rows: ReportRowLike[] | undefined,
  pattern: RegExp
): number {
  if (!rows) return 0;
  for (const r of rows) {
    if (r.rowType === "Section") {
      const fromChildren = findReportTotal(r.rows, pattern);
      if (fromChildren !== 0) return fromChildren;
    }
    const title = r.title || r.cells?.[0]?.value || "";
    if (r.rowType === "SummaryRow" && pattern.test(String(title))) {
      const cells = r.cells || [];
      for (let i = cells.length - 1; i >= 1; i--) {
        const v = cells[i].value;
        if (v && !Number.isNaN(parseFloat(v))) {
          return parseFloat(v);
        }
      }
    }
  }
  return 0;
}

/**
 * Bank Summary report has rows per bank account with cells:
 * [Account, Opening, Money In, Money Out, Closing]
 * We grab the closing balance as today's cash on hand.
 */
function parseBankSummary(
  rows: ReportRowLike[] | undefined
): BankAccountBalance[] {
  const out: BankAccountBalance[] = [];
  if (!rows) return out;
  for (const section of rows) {
    if (section.rowType !== "Section") continue;
    for (const r of section.rows || []) {
      if (r.rowType !== "Row" && r.rowType !== "SummaryRow") continue;
      const cells = r.cells || [];
      if (cells.length < 2) continue;
      const name = cells[0]?.value;
      const closing = cells[cells.length - 1]?.value;
      if (!name) continue;
      const balance = parseFloat(closing || "0") || 0;
      // Skip the totals row (no account context); keep only named accounts.
      if (r.rowType === "SummaryRow") continue;
      out.push({ name, balance });
    }
  }
  return out;
}

function bucketAging(
  invoices: Array<{ amountDue?: number; dueDate?: string }>
): AgedBucket[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const buckets: AgedBucket[] = [
    { label: "Current", total: 0, count: 0 },
    { label: "1-30 days", total: 0, count: 0 },
    { label: "31-60 days", total: 0, count: 0 },
    { label: "61-90 days", total: 0, count: 0 },
    { label: "90+ days", total: 0, count: 0 },
  ];
  for (const inv of invoices) {
    if (!inv.dueDate) continue;
    const due = new Date(inv.dueDate);
    const days = Math.floor(
      (today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24)
    );
    let idx = 0;
    if (days <= 0) idx = 0;
    else if (days <= 30) idx = 1;
    else if (days <= 60) idx = 2;
    else if (days <= 90) idx = 3;
    else idx = 4;
    buckets[idx].total += inv.amountDue || 0;
    buckets[idx].count += 1;
  }
  return buckets;
}

export async function loadDashboard(): Promise<DashboardData> {
  const { xero, tenantId, baseCurrency, tenantName } =
    await getXeroForRequest();

  const sixMonthsAgo = startOfMonthsAgo(5);
  const sixMonthsAgoXero = `${sixMonthsAgo.getFullYear()},${
    sixMonthsAgo.getMonth() + 1
  },${sixMonthsAgo.getDate()}`;

  const today = new Date();
  const yearStart = new Date(today.getFullYear(), 0, 1);
  const ytdFrom = isoDate(yearStart);
  const ytdTo = isoDate(today);

  // Xero caps each tenant at 5 concurrent requests. We need 8 calls for the
  // dashboard, so fire them in two waves of 4 to stay well under the limit
  // (otherwise we get 429 with x-rate-limit-problem: concurrent).
  const [invRes, contactRes, txnRes, pnlRes] = await Promise.all([
    // 6-month invoices for revenue chart + top customers (excludes drafts)
    xero.accountingApi.getInvoices(
      tenantId,
      undefined,
      `Date >= DateTime(${sixMonthsAgoXero}) AND Status!="VOIDED" AND Status!="DELETED" AND Status!="DRAFT"`,
      "Date DESC"
    ),
    xero.accountingApi.getContacts(tenantId),
    xero.accountingApi.getBankTransactions(
      tenantId,
      undefined,
      `Date >= DateTime(${sixMonthsAgoXero}) AND Status!="DELETED"`,
      "Date DESC"
    ),
    // P&L year-to-date for Net Profit + YTD revenue/expense
    xero.accountingApi.getReportProfitAndLoss(tenantId, ytdFrom, ytdTo),
  ]);

  const [receivablesRes, billsRes, bankRes, paidInvoicesRes] =
    await Promise.all([
      // Outstanding receivables (money owed to you) — Type ACCREC
      xero.accountingApi.getInvoices(
        tenantId,
        undefined,
        'Status=="AUTHORISED" AND Type=="ACCREC"',
        "DueDate ASC"
      ),
      // Bills to pay (money you owe) — Type ACCPAY
      xero.accountingApi.getInvoices(
        tenantId,
        undefined,
        'Status=="AUTHORISED" AND Type=="ACCPAY"',
        "DueDate ASC"
      ),
      // Bank Summary — fail-soft so a missing-scope error doesn't break the
      // whole dashboard. Most demo orgs grant accounting.reports.banksummary.read.
      xero.accountingApi
        .getReportBankSummary(
          tenantId,
          isoDate(new Date(today.getFullYear(), today.getMonth(), 1)),
          ytdTo
        )
        .catch(() => null),
      // Recent payments — derived from PAID invoices rather than /Payments
      // because PAID invoices already carry the invoice number + contact
      // name we want to display, no second lookup needed.
      xero.accountingApi.getInvoices(
        tenantId,
        undefined,
        'Status=="PAID" AND Type=="ACCREC"',
        "FullyPaidOnDate DESC"
      ),
    ]);

  const invoices = invRes.body.invoices || [];
  const contacts = contactRes.body.contacts || [];
  const txns = txnRes.body.bankTransactions || [];
  const receivables = receivablesRes.body.invoices || [];
  const bills = billsRes.body.invoices || [];

  // 6-month revenue/expense skeleton
  const months: Array<{ key: string; label: string }> = [];
  for (let i = 5; i >= 0; i--) {
    const d = startOfMonthsAgo(i);
    months.push({ key: monthKey(d), label: monthLabel(d) });
  }
  const monthly: MonthBucket[] = months.map((m) => ({
    month: m.label,
    revenue: 0,
    expense: 0,
  }));
  const monthIndex = new Map(months.map((m, i) => [m.key, i]));

  for (const inv of invoices) {
    if (!inv.date || !inv.total) continue;
    if ((inv.type as unknown as string) !== "ACCREC") continue; // sales only
    const idx = monthIndex.get(monthKey(new Date(inv.date)));
    if (idx === undefined) continue;
    monthly[idx].revenue += inv.total;
  }
  for (const t of txns) {
    if (!t.date || !t.total) continue;
    const idx = monthIndex.get(monthKey(new Date(t.date)));
    if (idx === undefined) continue;
    if ((t.type as unknown as string) === "SPEND")
      monthly[idx].expense += t.total;
  }

  // Top customers (sales only, last 6 months)
  const customerTotals = new Map<string, number>();
  for (const inv of invoices) {
    if ((inv.type as unknown as string) !== "ACCREC") continue;
    const name = inv.contact?.name || "Unknown";
    customerTotals.set(name, (customerTotals.get(name) || 0) + (inv.total || 0));
  }
  const topCustomers: TopCustomer[] = Array.from(customerTotals.entries())
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  // Receivables KPIs + aging
  const today0 = new Date();
  today0.setHours(0, 0, 0, 0);
  const outstandingTotal = receivables.reduce(
    (s, inv) => s + (inv.amountDue || 0),
    0
  );
  const overdueRecv = receivables.filter((inv) => {
    if (!inv.dueDate) return false;
    return new Date(inv.dueDate) < today0;
  });
  const outstandingOverdueTotal = overdueRecv.reduce(
    (s, inv) => s + (inv.amountDue || 0),
    0
  );

  // Bills KPIs + aging
  const billsTotal = bills.reduce((s, b) => s + (b.amountDue || 0), 0);
  const overdueBills = bills.filter((b) => {
    if (!b.dueDate) return false;
    return new Date(b.dueDate) < today0;
  });
  const billsOverdueTotal = overdueBills.reduce(
    (s, b) => s + (b.amountDue || 0),
    0
  );

  // P&L YTD
  const pnlReport = pnlRes.body.reports?.[0] as ReportRowLike | undefined;
  const netProfitYtd = findNetProfit(pnlReport?.rows);
  const ytdRevenue = findReportTotal(pnlReport?.rows, /total\s*income/i);
  const ytdExpense =
    findReportTotal(pnlReport?.rows, /total\s*expenses?/i) ||
    findReportTotal(pnlReport?.rows, /total\s*operating\s*expenses?/i);

  // Bank balances (gracefully empty if scope isn't granted)
  const bankReport = bankRes
    ? (bankRes.body.reports?.[0] as ReportRowLike | undefined)
    : undefined;
  const bankBalances = parseBankSummary(bankReport?.rows);
  const cashInBank = bankBalances.reduce((s, b) => s + b.balance, 0);

  const recentPayments: RecentPayment[] = (paidInvoicesRes.body.invoices || [])
    .slice(0, 8)
    .map((inv) => ({
      paymentID: inv.invoiceID,
      date: inv.fullyPaidOnDate || inv.date,
      amount: inv.total || 0,
      invoiceNumber: inv.invoiceNumber,
      contactName: inv.contact?.name,
      reference: inv.reference,
      currencyCode: inv.currencyCode as unknown as string | undefined,
    }));

  const currentMonthIdx = monthly.length - 1;

  // Cash flow forecast: projects net cash 8 weeks out using historical
  // payment lag per customer.
  const cashflow = buildCashflowForecast({
    receivables: receivables.map((inv) => ({
      contactID: inv.contact?.contactID,
      dueDate: inv.dueDate,
      amountDue: inv.amountDue,
    })),
    bills: bills.map((b) => ({
      dueDate: b.dueDate,
      amountDue: b.amountDue,
    })),
    paidInvoices: (paidInvoicesRes.body.invoices || []).map((inv) => ({
      contactID: inv.contact?.contactID,
      dueDate: inv.dueDate,
      fullyPaidOnDate: inv.fullyPaidOnDate,
    })),
    startingCash: cashInBank,
    weeks: 8,
  });

  return {
    baseCurrency,
    tenantName,
    outstandingTotal,
    outstandingCount: receivables.length,
    outstandingOverdueTotal,
    outstandingOverdueCount: overdueRecv.length,
    billsTotal,
    billsCount: bills.length,
    billsOverdueTotal,
    billsOverdueCount: overdueBills.length,
    thisMonthRevenue: monthly[currentMonthIdx]?.revenue || 0,
    thisMonthExpense: monthly[currentMonthIdx]?.expense || 0,
    netProfitYtd,
    ytdRevenue,
    ytdExpense,
    contactCount: contacts.length,
    bankBalances,
    cashInBank,
    monthly,
    topCustomers,
    agedBuckets: bucketAging(receivables),
    agedPayablesBuckets: bucketAging(bills),
    recentPayments,
    cashflow,
  };
}
