import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency = "USD") {
  return amount.toLocaleString(undefined, { style: "currency", currency });
}

/** Tight axis/tooltip label: "RM 12.3k" for >=1000, full format otherwise. */
export function compactCurrency(amount: number, currency: string) {
  if (Math.abs(amount) >= 1000) {
    return `${currency} ${(amount / 1000).toFixed(1)}k`;
  }
  return formatCurrency(amount, currency);
}

export function formatDate(value: string | Date | null | undefined) {
  if (!value) return "";
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString();
}

/**
 * xero-node parses date-shaped strings into JS Date objects, so the SDK's
 * `string` type definitions lie at runtime. Normalise to "YYYY-MM-DD" at the
 * server boundary so client components can safely string-manipulate them.
 */
export function toIsoDate(
  value: string | Date | null | undefined
): string | undefined {
  if (!value) return undefined;
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toISOString().slice(0, 10);
}
