import { XeroClient } from "xero-node";
import { redirect } from "next/navigation";
import { getSession, type SessionData } from "./session";

// ---------------------------------------------------------------------------
// Process-wide rate-limit safety net. Xero allows at most 5 concurrent
// requests per tenant (their docs); going over returns 429 with the header
// `x-rate-limit-problem: concurrent`. This semaphore caps every Xero call to
// 4 in flight at any moment, queueing any extras. Combined with automatic
// retry-on-429 below, navigation under load stops crashing.
// ---------------------------------------------------------------------------
const MAX_CONCURRENT_XERO_CALLS = 4;
let activeXeroCalls = 0;
const xeroWaitQueue: Array<() => void> = [];

function acquireXeroSlot(): Promise<void> {
  if (activeXeroCalls < MAX_CONCURRENT_XERO_CALLS) {
    activeXeroCalls++;
    return Promise.resolve();
  }
  return new Promise<void>((resolve) => {
    xeroWaitQueue.push(() => {
      activeXeroCalls++;
      resolve();
    });
  });
}

function releaseXeroSlot(): void {
  activeXeroCalls--;
  const next = xeroWaitQueue.shift();
  if (next) next();
}

async function callWithRetry<T>(fn: () => Promise<T>): Promise<T> {
  const maxAttempts = 4;
  for (let attempt = 0; ; attempt++) {
    await acquireXeroSlot();
    let caught: unknown;
    try {
      const result = await fn();
      releaseXeroSlot();
      return result;
    } catch (err) {
      caught = err;
    }
    // Release before sleeping so the slot can serve other in-flight callers.
    releaseXeroSlot();

    const e = caught as {
      response?: {
        statusCode?: number;
        headers?: Record<string, string>;
      };
    };
    const status = e?.response?.statusCode;
    if (status !== 429 || attempt >= maxAttempts - 1) throw caught;

    const problem = e?.response?.headers?.["x-rate-limit-problem"];
    // Concurrent overruns clear in milliseconds; minute/day overruns need
    // longer waits. We bias toward fast retries for the common case.
    const baseMs = problem === "concurrent" ? 250 : 1500;
    const delay = baseMs * Math.pow(2, attempt) + Math.random() * 200;
    await new Promise((r) => setTimeout(r, delay));
  }
}

function wrapAccountingApi<T extends object>(api: T): T {
  return new Proxy(api, {
    get(target, prop, receiver) {
      const orig = Reflect.get(target, prop, receiver);
      if (typeof orig !== "function") return orig;
      return (...args: unknown[]) =>
        callWithRetry(() =>
          (orig as (...a: unknown[]) => Promise<unknown>).apply(target, args)
        );
    },
  });
}

// Xero replaced the broad accounting.transactions / accounting.reports.read
// scopes with granular ones (apps created after 2026-03-02 can't request the
// broad versions at all). These are the granular scopes we need:
// - accounting.invoices         → /Invoices, /CreditNotes, /Quotes, etc.
// - accounting.payments         → /Payments, /BatchPayments, /Overpayments
// - accounting.banktransactions → /BankTransactions, /BankTransfers
// - accounting.contacts         → /Contacts, /ContactGroups
// - accounting.reports.*.read   → individual reports
// - accounting.settings.read    → org metadata, accounts, tax rates
export const SCOPES = [
  "openid",
  "profile",
  "email",
  "offline_access",
  "accounting.contacts",
  "accounting.invoices",
  "accounting.payments",
  "accounting.banktransactions",
  "accounting.reports.profitandloss.read",
  "accounting.reports.balancesheet.read",
  "accounting.reports.trialbalance.read",
  "accounting.reports.banksummary.read",
  "accounting.settings.read",
] as const;

function resolveRedirectUri() {
  if (process.env.REDIRECT_URI) return process.env.REDIRECT_URI;
  if (process.env.VERCEL_URL) {
    return `https://${process.env.VERCEL_URL}/api/auth/callback`;
  }
  return "http://localhost:3000/api/auth/callback";
}

export function createXeroClient(state?: string) {
  const clientId = process.env.XERO_CLIENT_ID;
  const clientSecret = process.env.XERO_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error(
      "XERO_CLIENT_ID / XERO_CLIENT_SECRET are not set. Copy .env.example to .env.local and fill them in."
    );
  }
  const client = new XeroClient({
    clientId,
    clientSecret,
    redirectUris: [resolveRedirectUri()],
    scopes: [...SCOPES],
    httpTimeout: 30000,
    state,
  });
  // Replace accountingApi with a Proxy that applies the concurrency cap and
  // 429 retry. The TS type is readonly but the runtime field is mutable.
  (client as unknown as { accountingApi: unknown }).accountingApi =
    wrapAccountingApi(client.accountingApi);
  return client;
}

async function saveQuietly(session: { save: () => Promise<void> }) {
  try {
    await session.save();
  } catch (err) {
    // Next 15 throws "Cookies can only be modified in a Server Action or
    // Route Handler" when invoked from a server component render. Swallow
    // it — the in-memory session stays valid for the current request.
    const msg = err instanceof Error ? err.message : String(err);
    if (!msg.includes("Cookies can only be modified")) throw err;
  }
}

/**
 * Hydrates a Xero client from the current session, refreshing if the access
 * token is within 60s of expiry. Redirects to /api/auth/login when the user
 * is not authenticated. Returns the live client + tenant context.
 */
export async function getXeroForRequest() {
  const session = await getSession();
  if (!session.access_token) {
    redirect("/api/auth/login");
  }

  const xero = createXeroClient();
  // refreshToken() calls this.openIdClient.refresh(...) directly. Unlike
  // buildConsentUrl/apiCallback, it does not initialize lazily — so without
  // this call openIdClient is undefined and we hit "Cannot read properties
  // of undefined (reading 'refresh')".
  await xero.initialize();
  await xero.setTokenSet({
    access_token: session.access_token,
    refresh_token: session.refresh_token,
    expires_at: session.expires_at,
  });

  const now = Math.floor(Date.now() / 1000);
  if (session.expires_at && session.expires_at - now < 60) {
    try {
      const refreshed = await xero.refreshToken();
      session.access_token = refreshed.access_token;
      session.refresh_token = refreshed.refresh_token;
      session.expires_at = refreshed.expires_at;
      // Server components can't write cookies in Next 15. The refreshed
      // token still lives on the session object for THIS request; if save
      // fails the cookie just isn't updated and we'll refresh again next.
      await saveQuietly(session);
    } catch (err) {
      // Refresh tokens are single-use; if a parallel dev server already
      // consumed it, or the user revoked the connection in Xero, we get
      // invalid_grant. Force a fresh OAuth round-trip rather than 500.
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes("invalid_grant") || msg.includes("Refresh token")) {
        redirect("/api/auth/login");
      }
      throw err;
    }
  }

  if (!session.tenantId) {
    await xero.updateTenants(false);
    const tenants = xero.tenants;
    if (tenants && tenants.length > 0) {
      session.tenantId = tenants[0].tenantId;
      session.tenantName = tenants[0].tenantName;
      await saveQuietly(session);
    }
  }

  if (!session.tenantId) {
    throw new Error("No Xero tenant connected to this session.");
  }

  return {
    xero,
    tenantId: session.tenantId,
    tenantName: session.tenantName,
    baseCurrency: session.baseCurrency || "MYR",
    countryCode: session.countryCode,
    session: session as SessionData & { save: () => Promise<void> },
  };
}

/**
 * Wraps a server-action body so any thrown xero-node error gets re-thrown
 * with the friendlier message extracted from its response body. Re-throws
 * Next.js internal control-flow errors (redirect, notFound) untouched.
 */
export async function withXeroErrors<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    if (
      err &&
      typeof err === "object" &&
      "digest" in err &&
      typeof (err as { digest?: unknown }).digest === "string" &&
      ((err as { digest: string }).digest.startsWith("NEXT_REDIRECT") ||
        (err as { digest: string }).digest.startsWith("NEXT_NOT_FOUND"))
    ) {
      throw err;
    }
    throw new Error(describeXeroError(err));
  }
}

/**
 * Pulls the most useful error message out of a xero-node error object so
 * server actions can surface validation failures rather than generic 500s.
 */
export function describeXeroError(err: unknown): string {
  // Log the raw error to the server console so we can inspect anything our
  // extractor doesn't surface (status code, headers, full body, etc.).
  console.error("[xero error]", err);

  const e = err as {
    response?: {
      statusCode?: number;
      status?: number;
      body?: unknown;
      headers?: Record<string, string>;
    };
    statusCode?: number;
    body?: unknown;
    message?: string;
  };

  const status = e?.response?.statusCode || e?.response?.status || e?.statusCode;

  // The body comes back as either a parsed object or a raw string; try to
  // coerce a string into JSON before walking it.
  let body: unknown = e?.response?.body ?? e?.body ?? null;
  if (typeof body === "string" && body.trim()) {
    try {
      body = JSON.parse(body);
    } catch {
      // Leave as string; we'll surface it below.
    }
  }

  if (body && typeof body === "object") {
    const b = body as Record<string, unknown>;

    // Schema validation errors come back nested under Elements[].ValidationErrors[].
    if (Array.isArray(b.Elements)) {
      const messages: string[] = [];
      for (const el of b.Elements as Array<Record<string, unknown>>) {
        const validations = el.ValidationErrors as
          | Array<Record<string, unknown>>
          | undefined;
        for (const v of validations || []) {
          if (v.Message) messages.push(String(v.Message));
        }
      }
      if (messages.length) return messages.join("; ");
    }

    // Standard problem-details body — Title/Detail/Message.
    const detail =
      (typeof b.Detail === "string" && b.Detail) ||
      (typeof b.Message === "string" && b.Message) ||
      (typeof b.Title === "string" && b.Title);
    if (detail) return status ? `Xero ${status}: ${detail}` : String(detail);
  }

  if (typeof body === "string" && body.trim()) {
    return status ? `Xero ${status}: ${body}` : body;
  }

  if (status) {
    if (status === 401) {
      return "Xero 401 Unauthorized — your access token doesn't include a scope required for this operation. Disconnect the org from Xero and re-authorise to pick up updated scopes.";
    }
    if (status === 403) return "Xero 403 Forbidden";
    if (status === 429) return "Xero 429 Rate limited — too many requests";
    if (status >= 500) return `Xero ${status} server error`;
    return `Xero ${status} error`;
  }

  if (typeof e?.message === "string" && e.message.trim()) {
    return e.message;
  }

  // Last-ditch: dump what we got so we can at least see something on screen.
  try {
    const own = Object.getOwnPropertyNames(err as object);
    const dump = JSON.stringify(err, own);
    return `Unhandled error: ${dump.slice(0, 500)}`;
  } catch {
    return `Unhandled error: ${String(err)}`;
  }
}
