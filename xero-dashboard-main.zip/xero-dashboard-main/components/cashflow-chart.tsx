"use client";

import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { CashflowBucket } from "@/lib/forecast";
import { compactCurrency, formatCurrency } from "@/lib/utils";

export function CashflowChart({
  buckets,
  baseCurrency,
}: {
  buckets: CashflowBucket[];
  baseCurrency: string;
}) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <ComposedChart
        data={buckets}
        margin={{ top: 8, right: 16, bottom: 8, left: 8 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="weekLabel" stroke="#64748b" fontSize={12} />
        <YAxis
          stroke="#64748b"
          fontSize={12}
          tickFormatter={(v) => compactCurrency(Number(v) || 0, baseCurrency)}
        />
        <Tooltip
          formatter={(value, name) => [
            formatCurrency(Number(value) || 0, baseCurrency),
            String(name),
          ]}
        />
        <Legend />
        <ReferenceLine y={0} stroke="#94a3b8" strokeDasharray="4 4" />
        <Bar dataKey="inflow" name="Money in" fill="#10b981" radius={[2, 2, 0, 0]} />
        <Bar
          dataKey="outflow"
          name="Money out"
          fill="#f97316"
          radius={[2, 2, 0, 0]}
        />
        <Area
          type="monotone"
          dataKey="netBalance"
          name="Projected balance"
          stroke="#13B5EA"
          fill="#13B5EA"
          fillOpacity={0.15}
          strokeWidth={2}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
