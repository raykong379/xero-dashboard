"use client";

import { useRouter } from "next/navigation";

interface Option {
  value: string;
  label: string;
}

/**
 * Native <select> that pushes its value into the URL search params on change,
 * so server components re-render with the new filter. Keeps JS minimal.
 */
export function AutoSubmitSelect({
  name,
  options,
  defaultValue = "",
  className = "rounded-md border border-slate-300 px-2 py-1.5 text-sm",
  id,
}: {
  name: string;
  options: Option[];
  defaultValue?: string;
  className?: string;
  id?: string;
}) {
  const router = useRouter();
  return (
    <select
      id={id}
      name={name}
      defaultValue={defaultValue}
      onChange={(e) => {
        const params = new URLSearchParams(window.location.search);
        if (e.target.value) params.set(name, e.target.value);
        else params.delete(name);
        const qs = params.toString();
        router.push(qs ? `?${qs}` : window.location.pathname);
      }}
      className={className}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
