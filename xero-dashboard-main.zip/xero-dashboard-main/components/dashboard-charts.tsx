"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { MonthBucket, TopCustomer } from "@/lib/dashboard-data";
import { compactCurrency, formatCurrency } from "@/lib/utils";

interface Props {
  monthly: MonthBucket[];
  topCustomers: TopCustomer[];
  baseCurrency: string;
}

export function RevenueExpenseChart({
  monthly,
  baseCurrency,
}: {
  monthly: MonthBucket[];
  baseCurrency: string;
}) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart
        data={monthly}
        margin={{ top: 8, right: 16, bottom: 8, left: 8 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
        <YAxis
          stroke="#64748b"
          fontSize={12}
          tickFormatter={(v) => compactCurrency(Number(v) || 0, baseCurrency)}
        />
        <Tooltip
          formatter={(value) =>
            formatCurrency(Number(value) || 0, baseCurrency)
          }
        />
        <Legend />
        <Line
          type="monotone"
          dataKey="revenue"
          name="Revenue"
          stroke="#13B5EA"
          strokeWidth={2}
          dot={{ r: 3 }}
        />
        <Line
          type="monotone"
          dataKey="expense"
          name="Expense"
          stroke="#ef4444"
          strokeWidth={2}
          dot={{ r: 3 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function TopCustomersChart({
  topCustomers,
  baseCurrency,
}: {
  topCustomers: TopCustomer[];
  baseCurrency: string;
}) {
  if (topCustomers.length === 0) {
    return (
      <div className="flex h-[260px] items-center justify-center text-sm text-slate-400">
        No customer activity yet.
      </div>
    );
  }
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart
        data={topCustomers}
        layout="vertical"
        margin={{ top: 8, right: 16, bottom: 8, left: 8 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis
          type="number"
          stroke="#64748b"
          fontSize={12}
          tickFormatter={(v) => compactCurrency(Number(v) || 0, baseCurrency)}
        />
        <YAxis
          type="category"
          dataKey="name"
          stroke="#64748b"
          fontSize={12}
          width={120}
        />
        <Tooltip
          formatter={(value) =>
            formatCurrency(Number(value) || 0, baseCurrency)
          }
        />
        <Bar dataKey="total" fill="#13B5EA" radius={[0, 4, 4, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function DashboardCharts({
  monthly,
  topCustomers,
  baseCurrency,
}: Props) {
  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
      <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-3 text-sm font-semibold text-slate-700">
          Revenue vs Expense (last 6 months)
        </h3>
        <RevenueExpenseChart
          monthly={monthly}
          baseCurrency={baseCurrency}
        />
      </div>
      <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-3 text-sm font-semibold text-slate-700">
          Top customers (last 6 months)
        </h3>
        <TopCustomersChart
          topCustomers={topCustomers}
          baseCurrency={baseCurrency}
        />
      </div>
    </div>
  );
}
