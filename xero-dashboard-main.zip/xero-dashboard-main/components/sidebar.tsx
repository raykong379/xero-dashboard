"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Dashboard" },
  { href: "/invoices", label: "Invoices" },
  { href: "/contacts", label: "Contacts" },
  { href: "/transactions", label: "Transactions" },
  { href: "/reports", label: "Reports" },
] as const;

function isActive(currentPath: string, href: string) {
  if (href === "/") return currentPath === "/";
  return currentPath === href || currentPath.startsWith(`${href}/`);
}

export function Sidebar({
  tenantName,
  showOrgSwitcher = false,
}: {
  tenantName?: string | null;
  showOrgSwitcher?: boolean;
}) {
  const pathname = usePathname() || "/";
  return (
    <aside className="flex w-60 flex-col border-r border-slate-200 bg-white">
      <div className="border-b border-slate-200 px-5 py-5">
        <div className="text-xs uppercase tracking-wider text-slate-400">
          Xero
        </div>
        <div className="text-lg font-semibold text-slate-800">Dashboard</div>
        {tenantName ? (
          <div
            className="mt-2 truncate text-xs text-slate-500"
            title={tenantName}
          >
            {tenantName}
          </div>
        ) : null}
        {showOrgSwitcher ? (
          <Link
            href="/select-org"
            className="mt-2 inline-block text-xs text-xero hover:underline"
          >
            Switch organisation →
          </Link>
        ) : null}
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4 text-sm">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "block rounded-md px-3 py-2",
              isActive(pathname, item.href)
                ? "bg-xero/10 font-medium text-xero"
                : "text-slate-600 hover:bg-slate-100"
            )}
          >
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="border-t border-slate-200 px-3 py-4">
        <Link
          href="/api/auth/logout"
          className="block rounded-md px-3 py-2 text-sm text-slate-600 hover:bg-slate-100"
        >
          Logout
        </Link>
      </div>
    </aside>
  );
}
