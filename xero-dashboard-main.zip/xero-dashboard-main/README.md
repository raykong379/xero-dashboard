# Xero Accounting Dashboard

A Next.js dashboard that connects to your Xero organisation over OAuth 2.0 and turns your accounting data into a live financial overview with forecasting and customer payment insights.

It lets you sign in with Xero, pick an organisation, and manage Invoices, Contacts, and Bank Transactions while viewing read-only financial reports — all from one clean web app. It is built for small-business owners and bookkeepers who want a faster, focused view of the numbers that matter.

## Features

- **Connect to Xero via OAuth 2.0** — sign in through Xero's consent screen; tokens are stored in a signed session cookie and refreshed automatically.
- **Multi-organisation support** — if your login has access to more than one Xero organisation, choose which one to work in from a selection screen.
- **Financial dashboard home** — see receivables and payables totals, overdue amounts, top customers, aged balances, bank account balances, and recent invoice payments at a glance.
- **8-week cash flow forecast** — projects incoming receivables (adjusted by each customer's historical payment lag) against bills due, charted as a running net cash balance.
- **Customer payment-behavior score** — rates each customer from their paid-invoice history with an average-days-late figure, a 0–10 score, and a plain-language label.
- **Invoices** — list, create, edit, and view invoices, with one-click download of the Xero-generated PDF.
- **Contacts** — list, search, create, and edit contacts.
- **Bank Transactions** — list, create, and edit bank transactions.
- **Reports** — read-only Profit & Loss (with a selectable date range), Balance Sheet, and Trial Balance.
- **Built-in rate-limit safety** — caps concurrent calls to Xero and automatically retries on rate-limit responses so heavy navigation stays stable.

## Tech Stack

- **Framework:** Next.js 15 (App Router) with React 19 and Server Actions for all mutations
- **Language:** TypeScript
- **Styling/UI:** Tailwind CSS with shadcn/ui components built on Radix primitives, Lucide icons
- **Charts:** Recharts
- **Xero integration:** `xero-node` SDK (Accounting API)
- **Sessions:** `iron-session` signed-cookie sessions (no server store — works on serverless)

## Getting Started

### Prerequisites

- Node.js 18.18 or newer
- A Xero developer app — register one at https://developer.xero.com/app/manage/ and add the redirect URI `http://localhost:3000/api/auth/callback`

### Installation

```bash
npm install
```

### Environment Variables

Copy `.env.example` to `.env.local` and fill in:

| Variable | Description |
|----------|-------------|
| `XERO_CLIENT_ID` | The Client ID of your registered Xero app |
| `XERO_CLIENT_SECRET` | The Client Secret of your registered Xero app |
| `REDIRECT_URI` | OAuth callback URL (e.g. `http://localhost:3000/api/auth/callback`). On Vercel this is auto-derived from the deployment URL if left unset. |
| `SESSION_SECRET` | A random string of at least 32 characters used to sign the session cookie |

### Running Locally

```bash
npm run dev
```

Then open http://localhost:3000 in your browser and click "Connect to Xero".

Other scripts:

| Script | What it does |
|---|---|
| `npm run build` | Production build |
| `npm start` | Run the production build |
| `npm run lint` | Next.js lint |
| `npm run typecheck` | TypeScript check (`tsc --noEmit`) |

## Project Structure

- `app/` — Next.js App Router pages and routes
  - `app/page.tsx` — dashboard home (totals, charts, forecast, recent payments)
  - `app/api/auth/` — Xero OAuth login, callback, and logout routes
  - `app/api/invoices/[id]/pdf/` — streams the Xero-generated invoice PDF
  - `app/select-org/` — organisation selection screen and action
  - `app/invoices/`, `app/contacts/`, `app/transactions/` — list/create/edit pages, clients, and Server Actions
  - `app/reports/` — Profit & Loss, Balance Sheet, and Trial Balance
- `components/` — UI components (sidebar, charts) and shadcn/ui primitives in `components/ui/`
- `lib/` — core logic: `xero.ts` (Xero client, rate limiting), `session.ts` (iron-session config), `dashboard-data.ts`, `forecast.ts` (cash flow), `payment-score.ts`, and `utils.ts` helpers

## Notes

- Deploying to Vercel: push the repo, set `XERO_CLIENT_ID`, `XERO_CLIENT_SECRET`, and `SESSION_SECRET` as environment variables, then add your deployment's `/api/auth/callback` URL to your Xero app's redirect URIs. The Xero client auto-derives the redirect from the deployment URL when `REDIRECT_URI` is unset.
- See `PRD.md` for the original product spec.
