import type { Metadata } from "next";
import { Sidebar } from "@/components/sidebar";
import { getSession } from "@/lib/session";
import "./globals.css";

export const metadata: Metadata = {
  title: "Xero Dashboard",
  description: "Xero accounting dashboard",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  const authed = Boolean(session.access_token);
  const tenantsCount = session.tenants?.length || 0;

  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-800">
        {authed && session.tenantId ? (
          <div className="flex min-h-screen">
            <Sidebar
              tenantName={session.tenantName}
              showOrgSwitcher={tenantsCount > 1}
            />
            <main className="flex-1 overflow-x-auto p-8">{children}</main>
          </div>
        ) : (
          <main className="min-h-screen">{children}</main>
        )}
      </body>
    </html>
  );
}
