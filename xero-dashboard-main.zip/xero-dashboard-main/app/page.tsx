import Link from "next/link";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DashboardCharts } from "@/components/dashboard-charts";
import { CashflowChart } from "@/components/cashflow-chart";
import { loadDashboard, type AgedBucket } from "@/lib/dashboard-data";
import { formatCurrency, formatDate, cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

const BUCKET_DOT: Record<string, string> = {
  Current: "bg-emerald-500",
  "1-30 days": "bg-amber-500",
  "31-60 days": "bg-orange-500",
  "61-90 days": "bg-rose-500",
  "90+ days": "bg-red-600",
};

const BUCKET_BAR: Record<string, string> = {
  Current: "bg-emerald-400",
  "1-30 days": "bg-amber-400",
  "31-60 days": "bg-orange-400",
  "61-90 days": "bg-rose-400",
  "90+ days": "bg-red-500",
};

function AgingBlock({
  buckets,
  baseCurrency,
}: {
  buckets: AgedBucket[];
  baseCurrency: string;
}) {
  const total = buckets.reduce((s, b) => s + b.total, 0);
  return (
    <>
      <div className="mb-5 flex h-2 w-full overflow-hidden rounded-full bg-slate-100">
        {buckets.map((b) => {
          const pct = total > 0 ? (b.total / total) * 100 : 0;
          if (pct === 0) return null;
          return (
            <div
              key={b.label}
              className={BUCKET_BAR[b.label]}
              style={{ width: `${pct}%` }}
              title={`${b.label}: ${formatCurrency(b.total, baseCurrency)} (${pct.toFixed(0)}%)`}
            />
          );
        })}
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {buckets.map((b) => {
          const empty = b.count === 0;
          const pct = total > 0 ? (b.total / total) * 100 : 0;
          return (
            <div
              key={b.label}
              className={cn(
                "rounded-lg border border-slate-200 bg-white px-4 py-3",
                empty && "opacity-50"
              )}
            >
              <div className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-slate-500">
                <span
                  className={cn(
                    "h-2 w-2 rounded-full",
                    BUCKET_DOT[b.label]
                  )}
                />
                {b.label}
              </div>
              <div className="mt-2 text-lg font-semibold tabular-nums text-slate-900">
                {formatCurrency(b.total, baseCurrency)}
              </div>
              <div className="mt-0.5 flex items-baseline justify-between text-xs text-slate-500">
                <span>
                  {b.count} invoice{b.count === 1 ? "" : "s"}
                </span>
                {!empty && total > 0 ? (
                  <span className="tabular-nums text-slate-400">
                    {pct.toFixed(0)}%
                  </span>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

export default async function DashboardPage() {
  const data = await loadDashboard();
  const profitPositive = data.netProfitYtd >= 0;

  return (
    <>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-slate-900">Dashboard</h1>
        <p className="mt-1 text-sm text-slate-500">
          {data.tenantName
            ? `Live view of ${data.tenantName}.`
            : "Live view of your Xero organisation."}
        </p>
      </div>

      {/* KPI strip — what an owner glances at first */}
      <div className="mb-8 grid grid-cols-2 gap-5 lg:grid-cols-4">
        {data.bankBalances.length > 0 ? (
          <Card>
            <CardHeader>
              <CardDescription className="text-xs uppercase tracking-wider">
                Cash in bank
              </CardDescription>
              <CardTitle className="text-2xl font-semibold tabular-nums text-slate-900">
                {formatCurrency(data.cashInBank, data.baseCurrency)}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-slate-500">
              Across {data.bankBalances.length} bank account
              {data.bankBalances.length === 1 ? "" : "s"}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardDescription className="text-xs uppercase tracking-wider">
                Contacts
              </CardDescription>
              <CardTitle className="text-2xl font-semibold tabular-nums text-slate-900">
                {data.contactCount}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-slate-500">
              Customers and suppliers
            </CardContent>
          </Card>
        )}
        <Card>
          <CardHeader>
            <CardDescription className="text-xs uppercase tracking-wider">
              Owed to you
            </CardDescription>
            <CardTitle className="text-2xl font-semibold tabular-nums text-slate-900">
              {formatCurrency(data.outstandingTotal, data.baseCurrency)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-slate-500">
            {data.outstandingCount} unpaid
            {data.outstandingOverdueCount > 0 ? (
              <span className="ml-1 text-red-600">
                · {data.outstandingOverdueCount} overdue
              </span>
            ) : null}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription className="text-xs uppercase tracking-wider">
              Bills to pay
            </CardDescription>
            <CardTitle className="text-2xl font-semibold tabular-nums text-slate-900">
              {formatCurrency(data.billsTotal, data.baseCurrency)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-slate-500">
            {data.billsCount} unpaid
            {data.billsOverdueCount > 0 ? (
              <span className="ml-1 text-red-600">
                · {data.billsOverdueCount} overdue
              </span>
            ) : null}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription className="text-xs uppercase tracking-wider">
              Net profit YTD
            </CardDescription>
            <CardTitle
              className={cn(
                "text-2xl font-semibold tabular-nums",
                profitPositive ? "text-emerald-700" : "text-red-700"
              )}
            >
              {formatCurrency(data.netProfitYtd, data.baseCurrency)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-slate-500">
            Income {formatCurrency(data.ytdRevenue, data.baseCurrency)} ·
            Expenses {formatCurrency(data.ytdExpense, data.baseCurrency)}
          </CardContent>
        </Card>
      </div>

      {/* Bank balances per account */}
      {data.bankBalances.length > 0 ? (
        <Card className="mb-8">
          <CardHeader className="border-b border-slate-200">
            <CardTitle className="text-base font-semibold">
              Bank accounts
            </CardTitle>
            <CardDescription>
              Closing balance for the current month.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-5">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
              {data.bankBalances.map((acc, i) => (
                <div
                  key={acc.accountID || `${acc.name}-${i}`}
                  className="rounded-lg border border-slate-200 bg-white px-4 py-3"
                >
                  <div className="text-xs font-medium uppercase tracking-wider text-slate-500">
                    {acc.name}
                  </div>
                  <div
                    className={cn(
                      "mt-1 text-xl font-semibold tabular-nums",
                      acc.balance < 0 ? "text-red-700" : "text-slate-900"
                    )}
                  >
                    {formatCurrency(acc.balance, data.baseCurrency)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : null}

      <div className="mb-8">
        <DashboardCharts
          monthly={data.monthly}
          topCustomers={data.topCustomers}
          baseCurrency={data.baseCurrency}
        />
      </div>

      <Card className="mb-8 overflow-hidden">
        <CardHeader className="border-b border-slate-200">
          <CardTitle className="text-base font-semibold">
            Cash flow forecast — next 8 weeks
          </CardTitle>
          <CardDescription>
            Projects when unpaid invoices will arrive (using each
            customer&apos;s historical payment lag) versus bills due. The line
            shows your projected cash balance.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-5">
          <CashflowChart
            buckets={data.cashflow}
            baseCurrency={data.baseCurrency}
          />
          {(() => {
            const negative = data.cashflow.find((b) => b.netBalance < 0);
            if (!negative) return null;
            return (
              <div className="mt-4 rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                <strong>Heads up:</strong> projected balance dips below zero
                around <strong>{negative.weekLabel}</strong>. Consider chasing
                overdue receivables or delaying non-essential bills.
              </div>
            );
          })()}
        </CardContent>
      </Card>

      {/* Aged Receivables */}
      <Card className="mb-8 overflow-hidden">
        <CardHeader className="flex-row items-center justify-between border-b border-slate-200">
          <div>
            <CardTitle className="text-base font-semibold">
              Aged Receivables
            </CardTitle>
            <CardDescription>
              How long unpaid invoices have been outstanding.
            </CardDescription>
          </div>
          <Link
            href="/invoices?status=AUTHORISED"
            className="text-sm text-xero hover:underline"
          >
            View all unpaid →
          </Link>
        </CardHeader>
        <CardContent className="pt-5">
          <AgingBlock
            buckets={data.agedBuckets}
            baseCurrency={data.baseCurrency}
          />
        </CardContent>
      </Card>

      {/* Aged Payables */}
      <Card className="mb-8 overflow-hidden">
        <CardHeader className="flex-row items-center justify-between border-b border-slate-200">
          <div>
            <CardTitle className="text-base font-semibold">
              Aged Payables
            </CardTitle>
            <CardDescription>
              Bills due to suppliers, by how long they&apos;ve been outstanding.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="pt-5">
          <AgingBlock
            buckets={data.agedPayablesBuckets}
            baseCurrency={data.baseCurrency}
          />
        </CardContent>
      </Card>

      {/* Recent invoice payments — matches Xero's own dashboard widget */}
      <Card className="overflow-hidden">
        <CardHeader className="flex-row items-center justify-between border-b border-slate-200">
          <CardTitle className="text-base font-semibold">
            Recent invoice payments
          </CardTitle>
          <Link
            href="/invoices?status=PAID"
            className="text-sm text-xero hover:underline"
          >
            View paid invoices →
          </Link>
        </CardHeader>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Date received</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.recentPayments.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={4}
                  className="py-6 text-center text-slate-400"
                >
                  No payments recorded yet.
                </TableCell>
              </TableRow>
            ) : (
              data.recentPayments.map((p, i) => (
                <TableRow key={p.paymentID || i}>
                  <TableCell className="font-medium text-slate-800">
                    {p.invoiceNumber || "—"}
                  </TableCell>
                  <TableCell>{p.contactName || "—"}</TableCell>
                  <TableCell>{formatDate(p.date)}</TableCell>
                  <TableCell className="text-right tabular-nums">
                    {formatCurrency(
                      p.amount,
                      p.currencyCode || data.baseCurrency
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </>
  );
}
