"use server";

import { revalidatePath } from "next/cache";
import { getXeroForRequest, withXeroErrors } from "@/lib/xero";
import { toIsoDate } from "@/lib/utils";

/**
 * Re-fetch a single bank transaction so the Edit dialog gets line items
 * (description, unitAmount), which can be missing in the list response.
 */
export async function getTransactionForEdit(txnId: string) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const result = await xero.accountingApi.getBankTransaction(
      tenantId,
      txnId
    );
    const t = result.body.bankTransactions?.[0];
    if (!t) throw new Error("Transaction not found.");
    return {
      bankTransactionID: t.bankTransactionID || txnId,
      type: t.type as unknown as string | undefined,
      status: t.status as unknown as string | undefined,
      date: toIsoDate(t.date),
      total: t.total,
      contact: t.contact
        ? { contactID: t.contact.contactID, name: t.contact.name }
        : undefined,
      bankAccount: t.bankAccount
        ? { accountID: t.bankAccount.accountID, name: t.bankAccount.name }
        : undefined,
      lineItems: (t.lineItems || []).map((li) => ({
        description: li.description,
        unitAmount: li.unitAmount,
      })),
    };
  });
}

interface TxnFormShape {
  type: string;
  accountId: string;
  contactId: string;
  date: string;
  description: string;
  amount: number;
}

function readTxnForm(formData: FormData): TxnFormShape {
  return {
    type: String(formData.get("type") ?? "SPEND"),
    accountId: String(formData.get("accountId") ?? ""),
    contactId: String(formData.get("contactId") ?? ""),
    date: String(formData.get("date") ?? ""),
    description: String(formData.get("description") ?? ""),
    amount: Number(formData.get("amount") ?? 0),
  };
}

function buildTxnPayload(d: TxnFormShape) {
  return {
    type: d.type as never,
    contact: { contactID: d.contactId },
    bankAccount: { accountID: d.accountId },
    date: d.date,
    lineItems: [
      {
        description: d.description,
        quantity: 1,
        unitAmount: d.amount,
        accountCode: "400",
      },
    ],
  };
}

export async function createTransaction(formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readTxnForm(formData);
    await xero.accountingApi.createBankTransactions(tenantId, {
      bankTransactions: [buildTxnPayload(data)],
    });
    revalidatePath("/transactions");
    revalidatePath("/");
  });
}

export async function updateTransaction(txnId: string, formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readTxnForm(formData);
    await xero.accountingApi.updateBankTransaction(tenantId, txnId, {
      bankTransactions: [{ bankTransactionID: txnId, ...buildTxnPayload(data) }],
    });
    revalidatePath("/transactions");
  });
}
