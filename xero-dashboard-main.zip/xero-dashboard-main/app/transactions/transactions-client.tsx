"use client";

import { useState, useTransition } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
  createTransaction,
  getTransactionForEdit,
  updateTransaction,
} from "./actions";

export interface TxnLineItem {
  description?: string;
  unitAmount?: number;
}

export interface TxnRow {
  bankTransactionID: string;
  type?: string;
  status?: string;
  date?: string;
  total?: number;
  currencyCode?: string;
  contact?: { contactID?: string; name?: string };
  bankAccount?: { accountID?: string; name?: string };
  lineItems?: TxnLineItem[];
}

export interface AccountOption {
  accountID: string;
  name: string;
}

export interface ContactOption {
  contactID: string;
  name: string;
}

export function TransactionsClient({
  transactions,
  accounts,
  contacts,
  baseCurrency,
}: {
  transactions: TxnRow[];
  accounts: AccountOption[];
  contacts: ContactOption[];
  baseCurrency: string;
}) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<TxnRow | null>(null);
  const [type, setType] = useState("SPEND");
  const [accountId, setAccountId] = useState("");
  const [contactId, setContactId] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("0");
  const [pending, startTransition] = useTransition();

  function openCreate() {
    setEditing(null);
    setType("SPEND");
    setAccountId("");
    setContactId("");
    setDate("");
    setDescription("");
    setAmount("0");
    setOpen(true);
  }

  function openEdit(t: TxnRow) {
    // Pre-populate from list data so the dialog opens instantly, then
    // refresh from the single-transaction endpoint to fill in any line
    // items the list response may omit.
    setEditing(t);
    setType(t.type || "SPEND");
    setAccountId(t.bankAccount?.accountID || "");
    setContactId(t.contact?.contactID || "");
    setDate(t.date ? t.date.slice(0, 10) : "");
    const li = (t.lineItems || [])[0];
    setDescription(li?.description || "");
    setAmount(String(li?.unitAmount ?? t.total ?? 0));
    setOpen(true);

    startTransition(async () => {
      const fresh = await getTransactionForEdit(t.bankTransactionID);
      setEditing({ ...t, ...fresh });
      if (fresh.type) setType(fresh.type);
      if (fresh.bankAccount?.accountID)
        setAccountId(fresh.bankAccount.accountID);
      if (fresh.contact?.contactID) setContactId(fresh.contact.contactID);
      if (fresh.date) setDate(fresh.date);
      const freshLi = (fresh.lineItems || [])[0];
      if (freshLi) {
        if (freshLi.description) setDescription(freshLi.description);
        if (freshLi.unitAmount !== undefined)
          setAmount(String(freshLi.unitAmount));
      }
    });
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData();
    fd.set("type", type);
    fd.set("accountId", accountId);
    fd.set("contactId", contactId);
    fd.set("date", date);
    fd.set("description", description);
    fd.set("amount", amount);
    startTransition(async () => {
      if (editing) {
        await updateTransaction(editing.bankTransactionID, fd);
      } else {
        await createTransaction(fd);
      }
      setOpen(false);
    });
  }

  return (
    <>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Bank Transactions
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Spend & receive money entries.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> New Transaction
        </Button>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Account</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="py-6 text-center text-slate-400">
                  No transactions.
                </TableCell>
              </TableRow>
            ) : (
              transactions.map((t) => (
                <TableRow key={t.bankTransactionID}>
                  <TableCell>{formatDate(t.date)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={t.type === "RECEIVE" ? "success" : "warning"}
                    >
                      {t.type}
                    </Badge>
                  </TableCell>
                  <TableCell>{t.contact?.name || "—"}</TableCell>
                  <TableCell className="text-slate-600">
                    {t.bankAccount?.name || "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(
                      t.total || 0,
                      t.currencyCode || baseCurrency
                    )}
                  </TableCell>
                  <TableCell className="text-center text-xs">
                    {t.status}
                  </TableCell>
                  <TableCell className="text-right">
                    {t.status !== "DELETED" ? (
                      <button
                        type="button"
                        onClick={() => openEdit(t)}
                        className="text-sm text-xero hover:underline"
                        disabled={pending}
                      >
                        Edit
                      </button>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit transaction" : "New bank transaction"}
            </DialogTitle>
            <p className="text-sm text-slate-500">
              Record money moving in or out of your bank account.
            </p>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label>Money in or out?</Label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setType("RECEIVE")}
                  className={`rounded-md border px-4 py-3 text-left transition-colors ${
                    type === "RECEIVE"
                      ? "border-emerald-300 bg-emerald-50 text-emerald-900"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <div className="text-sm font-semibold">Money in</div>
                  <div className="text-xs text-slate-500">
                    Customer paid you
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setType("SPEND")}
                  className={`rounded-md border px-4 py-3 text-left transition-colors ${
                    type === "SPEND"
                      ? "border-amber-300 bg-amber-50 text-amber-900"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <div className="text-sm font-semibold">Money out</div>
                  <div className="text-xs text-slate-500">
                    You paid someone
                  </div>
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="txn-account">
                  Bank account <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={accountId}
                  onValueChange={setAccountId}
                  required
                >
                  <SelectTrigger id="txn-account">
                    <SelectValue placeholder="Choose an account..." />
                  </SelectTrigger>
                  <SelectContent>
                    {accounts.map((a) => (
                      <SelectItem key={a.accountID} value={a.accountID}>
                        {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="txn-date">
                  Date <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="txn-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="txn-contact">
                {type === "RECEIVE" ? "Who paid you?" : "Who did you pay?"}{" "}
                <span className="text-red-500">*</span>
              </Label>
              <Select value={contactId} onValueChange={setContactId} required>
                <SelectTrigger id="txn-contact">
                  <SelectValue placeholder="Choose a contact..." />
                </SelectTrigger>
                <SelectContent>
                  {contacts.map((c) => (
                    <SelectItem key={c.contactID} value={c.contactID}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="txn-desc">
                What was it for? <span className="text-red-500">*</span>
              </Label>
              <Input
                id="txn-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={
                  type === "RECEIVE"
                    ? "e.g. Invoice payment, refund received"
                    : "e.g. Office rent, supplier payment"
                }
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="txn-amount">
                Amount ({baseCurrency}){" "}
                <span className="text-red-500">*</span>
              </Label>
              <Input
                id="txn-amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={Number(amount) ? amount : ""}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setOpen(false)}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={pending}>
                {pending
                  ? "Saving..."
                  : editing
                    ? "Save changes"
                    : "Record transaction"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
