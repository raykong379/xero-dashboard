import Link from "next/link";
import { getXeroForRequest } from "@/lib/xero";
import { toIsoDate } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  TransactionsClient,
  type AccountOption,
  type ContactOption,
  type TxnRow,
} from "./transactions-client";

export const dynamic = "force-dynamic";

function buildWhere(from?: string, to?: string) {
  if (from && to) {
    return `Date >= DateTime(${from.replace(/-/g, ",")}) && Date <= DateTime(${to.replace(/-/g, ",")})`;
  }
  return undefined;
}

export default async function TransactionsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const { from = "", to = "" } = await searchParams;
  const { xero, tenantId, baseCurrency } = await getXeroForRequest();
  const where = buildWhere(from, to);
  const [txnRes, acctRes, contactRes] = await Promise.all([
    xero.accountingApi.getBankTransactions(
      tenantId,
      undefined,
      where,
      "Date DESC"
    ),
    xero.accountingApi.getAccounts(tenantId, undefined, 'Type=="BANK"'),
    xero.accountingApi.getContacts(tenantId),
  ]);

  const transactions: TxnRow[] = (txnRes.body.bankTransactions || []).map(
    (t) => ({
      bankTransactionID: t.bankTransactionID || "",
      type: t.type as unknown as string | undefined,
      status: t.status as unknown as string | undefined,
      date: toIsoDate(t.date),
      total: t.total,
      currencyCode: t.currencyCode as unknown as string | undefined,
      contact: t.contact
        ? { contactID: t.contact.contactID, name: t.contact.name }
        : undefined,
      bankAccount: t.bankAccount
        ? { accountID: t.bankAccount.accountID, name: t.bankAccount.name }
        : undefined,
      lineItems: (t.lineItems || []).map((li) => ({
        description: li.description,
        unitAmount: li.unitAmount,
      })),
    })
  );

  const accounts: AccountOption[] = (acctRes.body.accounts || [])
    .filter((a) => a.accountID && a.name)
    .map((a) => ({ accountID: a.accountID!, name: a.name! }));

  const contacts: ContactOption[] = (contactRes.body.contacts || [])
    .filter((c) => c.contactID && c.name)
    .map((c) => ({ contactID: c.contactID!, name: c.name! }));

  return (
    <>
      <form className="mb-4 flex items-center gap-2 text-sm">
        <label className="text-slate-500" htmlFor="from">
          From
        </label>
        <Input
          type="date"
          id="from"
          name="from"
          defaultValue={from}
          className="w-auto"
        />
        <label className="text-slate-500" htmlFor="to">
          To
        </label>
        <Input
          type="date"
          id="to"
          name="to"
          defaultValue={to}
          className="w-auto"
        />
        <Button type="submit" variant="secondary">
          Filter
        </Button>
        {from || to ? (
          <Link
            href="/transactions"
            className="text-slate-500 hover:underline"
          >
            Clear
          </Link>
        ) : null}
      </form>
      <TransactionsClient
        transactions={transactions}
        accounts={accounts}
        contacts={contacts}
        baseCurrency={baseCurrency}
      />
    </>
  );
}
