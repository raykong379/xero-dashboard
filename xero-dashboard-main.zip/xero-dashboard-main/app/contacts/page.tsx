import { getXeroForRequest } from "@/lib/xero";
import { computeContactScores } from "@/lib/payment-score";
import { ContactsClient, type ContactRow } from "./contacts-client";
import { ContactsSearch } from "./contacts-search";

export const dynamic = "force-dynamic";

export default async function ContactsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const { xero, tenantId } = await getXeroForRequest();
  const trimmed = q.trim();
  const where = trimmed
    ? `Name.Contains("${trimmed.replace(/"/g, '\\"')}")`
    : undefined;

  // Fetch contacts and historical paid invoices in parallel — paid invoices
  // power the per-customer payment score column.
  const [contactsRes, paidRes] = await Promise.all([
    xero.accountingApi.getContacts(tenantId, undefined, where, "Name ASC"),
    xero.accountingApi.getInvoices(
      tenantId,
      undefined,
      'Status=="PAID" AND Type=="ACCREC"',
      "FullyPaidOnDate DESC"
    ),
  ]);

  const scores = computeContactScores(
    (paidRes.body.invoices || []).map((inv) => ({
      contactID: inv.contact?.contactID,
      dueDate: inv.dueDate,
      fullyPaidOnDate: inv.fullyPaidOnDate,
    }))
  );

  const contacts: ContactRow[] = (contactsRes.body.contacts || []).map((c) => {
    const phone = (c.phones || []).find((p) => p.phoneNumber);
    const score = c.contactID ? scores.get(c.contactID) : undefined;
    return {
      contactID: c.contactID || "",
      name: c.name,
      emailAddress: c.emailAddress,
      phone: phone?.phoneNumber,
      isCustomer: c.isCustomer,
      isSupplier: c.isSupplier,
      contactStatus: c.contactStatus as string | undefined,
      paymentScore: score
        ? {
            avgDaysLate: score.avgDaysLate,
            invoicesPaid: score.invoicesPaid,
            score: score.score,
            label: score.label,
          }
        : undefined,
    };
  });

  return (
    <>
      <ContactsSearch defaultValue={trimmed} />
      <ContactsClient contacts={contacts} />
    </>
  );
}
