"use client";

import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";

export function ContactsSearch({ defaultValue }: { defaultValue: string }) {
  const router = useRouter();
  return (
    <form
      className="mb-4"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const q = String(fd.get("q") || "").trim();
        router.push(q ? `?q=${encodeURIComponent(q)}` : window.location.pathname);
      }}
    >
      <Input
        name="q"
        defaultValue={defaultValue}
        placeholder="Search contacts by name..."
        className="w-80"
      />
    </form>
  );
}
