"use server";

import { revalidatePath } from "next/cache";
import { getXeroForRequest, withXeroErrors } from "@/lib/xero";

interface ContactFormShape {
  name: string;
  email: string;
  phone: string;
  isCustomer: boolean;
  isSupplier: boolean;
}

function readContactForm(formData: FormData): ContactFormShape {
  return {
    name: String(formData.get("name") ?? ""),
    email: String(formData.get("email") ?? ""),
    phone: String(formData.get("phone") ?? ""),
    isCustomer: formData.get("isCustomer") === "on",
    isSupplier: formData.get("isSupplier") === "on",
  };
}

function buildContactPayload(d: ContactFormShape) {
  return {
    name: d.name,
    emailAddress: d.email || undefined,
    phones: d.phone
      ? [{ phoneType: "DEFAULT" as never, phoneNumber: d.phone }]
      : undefined,
    isCustomer: d.isCustomer,
    isSupplier: d.isSupplier,
  };
}

export async function createContact(formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readContactForm(formData);
    await xero.accountingApi.createContacts(tenantId, {
      contacts: [buildContactPayload(data)],
    });
    revalidatePath("/contacts");
    revalidatePath("/");
  });
}

export async function updateContact(contactId: string, formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readContactForm(formData);
    await xero.accountingApi.updateContact(tenantId, contactId, {
      contacts: [{ contactID: contactId, ...buildContactPayload(data) }],
    });
    revalidatePath("/contacts");
  });
}

export async function archiveContact(contactId: string) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    await xero.accountingApi.updateContact(tenantId, contactId, {
      contacts: [{ contactID: contactId, contactStatus: "ARCHIVED" as never }],
    });
    revalidatePath("/contacts");
  });
}
