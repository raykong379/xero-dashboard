"use client";

import { useState, useTransition } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { archiveContact, createContact, updateContact } from "./actions";

export interface ContactRow {
  contactID: string;
  name?: string;
  emailAddress?: string;
  phone?: string;
  isCustomer?: boolean;
  isSupplier?: boolean;
  contactStatus?: string;
  paymentScore?: {
    avgDaysLate: number;
    invoicesPaid: number;
    score: number;
    label: "great" | "good" | "average" | "slow" | "bad" | "unknown";
  };
}

const PAY_LABEL_TONE: Record<string, string> = {
  great: "bg-emerald-100 text-emerald-800",
  good: "bg-emerald-50 text-emerald-700",
  average: "bg-amber-50 text-amber-700",
  slow: "bg-orange-50 text-orange-700",
  bad: "bg-red-50 text-red-700",
  unknown: "bg-slate-100 text-slate-500",
};

const PAY_LABEL_TEXT: Record<string, string> = {
  great: "Pays early",
  good: "On time",
  average: "Slightly late",
  slow: "Often late",
  bad: "Very late",
  unknown: "—",
};

export function ContactsClient({ contacts }: { contacts: ContactRow[] }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ContactRow | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [isCustomer, setIsCustomer] = useState(false);
  const [isSupplier, setIsSupplier] = useState(false);
  const [pending, startTransition] = useTransition();

  function openCreate() {
    setEditing(null);
    setName("");
    setEmail("");
    setPhone("");
    setIsCustomer(false);
    setIsSupplier(false);
    setOpen(true);
  }

  function openEdit(c: ContactRow) {
    setEditing(c);
    setName(c.name || "");
    setEmail(c.emailAddress || "");
    setPhone(c.phone || "");
    setIsCustomer(!!c.isCustomer);
    setIsSupplier(!!c.isSupplier);
    setOpen(true);
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData();
    fd.set("name", name);
    fd.set("email", email);
    fd.set("phone", phone);
    if (isCustomer) fd.set("isCustomer", "on");
    if (isSupplier) fd.set("isSupplier", "on");
    startTransition(async () => {
      if (editing) {
        await updateContact(editing.contactID, fd);
      } else {
        await createContact(fd);
      }
      setOpen(false);
    });
  }

  function handleArchive(c: ContactRow) {
    if (!confirm("Archive this contact?")) return;
    startTransition(async () => {
      await archiveContact(c.contactID);
    });
  }

  return (
    <>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Contacts</h1>
          <p className="mt-1 text-sm text-slate-500">
            Customers and suppliers.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> New Contact
        </Button>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead className="text-center">Type</TableHead>
              <TableHead className="text-center">Pays</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {contacts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="py-6 text-center text-slate-400">
                  No contacts.
                </TableCell>
              </TableRow>
            ) : (
              contacts.map((c) => (
                <TableRow key={c.contactID}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell className="text-slate-600">
                    {c.emailAddress || "—"}
                  </TableCell>
                  <TableCell className="text-slate-600">
                    {c.phone || "—"}
                  </TableCell>
                  <TableCell className="space-x-1 text-center">
                    {c.isCustomer ? <Badge variant="info">Customer</Badge> : null}
                    {c.isSupplier ? <Badge variant="purple">Supplier</Badge> : null}
                  </TableCell>
                  <TableCell className="text-center">
                    {c.paymentScore ? (
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ${PAY_LABEL_TONE[c.paymentScore.label]}`}
                        title={`${c.paymentScore.invoicesPaid} paid invoices · avg ${c.paymentScore.avgDaysLate >= 0 ? "+" : ""}${c.paymentScore.avgDaysLate.toFixed(0)} days vs due date`}
                      >
                        {PAY_LABEL_TEXT[c.paymentScore.label]}
                        {c.paymentScore.label !== "unknown" ? (
                          <span className="tabular-nums opacity-70">
                            {c.paymentScore.score.toFixed(1)}
                          </span>
                        ) : null}
                      </span>
                    ) : (
                      <span className="text-xs text-slate-400">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge
                      variant={c.contactStatus === "ACTIVE" ? "success" : "muted"}
                    >
                      {c.contactStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="space-x-3 text-right">
                    <button
                      type="button"
                      onClick={() => openEdit(c)}
                      className="text-sm text-xero hover:underline"
                      disabled={pending}
                    >
                      Edit
                    </button>
                    {c.contactStatus === "ACTIVE" ? (
                      <button
                        type="button"
                        onClick={() => handleArchive(c)}
                        className="text-sm text-red-600 hover:underline disabled:opacity-50"
                        disabled={pending}
                      >
                        Archive
                      </button>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editing ? `Edit ${editing.name || "contact"}` : "New contact"}
            </DialogTitle>
            <p className="text-sm text-slate-500">
              {editing
                ? "Update contact details and save."
                : "Add a customer, supplier, or both."}
            </p>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="contact-name">
                Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="contact-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Acme Sdn Bhd"
                required
              />
              <p className="text-xs text-slate-500">
                Company name or person&apos;s full name.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="contact-email">Email</Label>
                <Input
                  id="contact-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="billing@acme.com.my"
                />
                <p className="text-xs text-slate-500">
                  Used when emailing invoices.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="contact-phone">Phone</Label>
                <Input
                  id="contact-phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+60 12-345 6789"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>What kind of contact?</Label>
              <div className="flex gap-3">
                <label
                  className={`flex flex-1 cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors ${
                    isCustomer
                      ? "border-xero/40 bg-xero/5 text-slate-900"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isCustomer}
                    onChange={(e) => setIsCustomer(e.target.checked)}
                    className="h-4 w-4"
                  />
                  <div>
                    <div className="font-medium">Customer</div>
                    <div className="text-xs text-slate-500">
                      You bill them
                    </div>
                  </div>
                </label>
                <label
                  className={`flex flex-1 cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors ${
                    isSupplier
                      ? "border-xero/40 bg-xero/5 text-slate-900"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isSupplier}
                    onChange={(e) => setIsSupplier(e.target.checked)}
                    className="h-4 w-4"
                  />
                  <div>
                    <div className="font-medium">Supplier</div>
                    <div className="text-xs text-slate-500">
                      They bill you
                    </div>
                  </div>
                </label>
              </div>
              <p className="text-xs text-slate-500">
                Tick both if they&apos;re both — like a co-vendor.
              </p>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setOpen(false)}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={pending}>
                {pending
                  ? "Saving..."
                  : editing
                    ? "Save changes"
                    : "Add contact"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
