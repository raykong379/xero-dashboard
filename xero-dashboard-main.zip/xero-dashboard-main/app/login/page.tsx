import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
        <div className="text-xs uppercase tracking-wider text-slate-400">
          Xero
        </div>
        <h1 className="mt-1 text-2xl font-semibold text-slate-900">
          Dashboard
        </h1>
        <p className="mt-2 text-sm text-slate-500">
          Connect your Xero organisation to view invoices, contacts, bank
          transactions, and reports.
        </p>
        <Button asChild className="mt-6 w-full">
          <Link href="/api/auth/login">Connect to Xero</Link>
        </Button>
      </div>
    </div>
  );
}
