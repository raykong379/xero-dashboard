"use server";

import { revalidatePath } from "next/cache";
import { getXeroForRequest, withXeroErrors } from "@/lib/xero";
import { toIsoDate } from "@/lib/utils";

/**
 * The list endpoint sometimes returns invoices with empty / missing line
 * items. To populate the Edit dialog reliably we re-fetch the single invoice
 * which always includes the full record.
 */
export async function getInvoiceForEdit(invoiceId: string) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const result = await xero.accountingApi.getInvoice(tenantId, invoiceId);
    const inv = result.body.invoices?.[0];
    if (!inv) throw new Error("Invoice not found.");
    return {
      invoiceID: inv.invoiceID || invoiceId,
      invoiceNumber: inv.invoiceNumber,
      status: inv.status as unknown as string | undefined,
      date: toIsoDate(inv.date),
      dueDate: toIsoDate(inv.dueDate),
      contact: inv.contact
        ? { contactID: inv.contact.contactID, name: inv.contact.name }
        : undefined,
      lineItems: (inv.lineItems || []).map((li) => ({
        description: li.description,
        quantity: li.quantity,
        unitAmount: li.unitAmount,
      })),
    };
  });
}

interface InvoiceFormShape {
  contactId: string;
  date: string;
  dueDate: string;
  status: string;
  lines: Array<{ description: string; quantity: number; unitAmount: number }>;
}

function readInvoiceForm(formData: FormData): InvoiceFormShape {
  const descriptions = formData.getAll("lineDescription").map(String);
  const quantities = formData.getAll("lineQuantity").map(String);
  const unitAmounts = formData.getAll("lineUnitAmount").map(String);
  const lines = descriptions.map((desc, i) => ({
    description: desc,
    quantity: Number(quantities[i] ?? 1),
    unitAmount: Number(unitAmounts[i] ?? 0),
  }));
  return {
    contactId: String(formData.get("contactId") ?? ""),
    date: String(formData.get("date") ?? ""),
    dueDate: String(formData.get("dueDate") ?? ""),
    status: String(formData.get("status") ?? "DRAFT"),
    lines,
  };
}

export async function createInvoice(formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readInvoiceForm(formData);
    await xero.accountingApi.createInvoices(tenantId, {
      invoices: [
        {
          type: "ACCREC" as never,
          contact: { contactID: data.contactId },
          date: data.date,
          dueDate: data.dueDate,
          status: data.status as never,
          lineItems: data.lines.map((l) => ({
            description: l.description,
            quantity: l.quantity,
            unitAmount: l.unitAmount,
            accountCode: "200",
          })),
        },
      ],
    });
    revalidatePath("/invoices");
    revalidatePath("/");
  });
}

export async function updateInvoice(invoiceId: string, formData: FormData) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const data = readInvoiceForm(formData);
    await xero.accountingApi.updateInvoice(tenantId, invoiceId, {
      invoices: [
        {
          invoiceID: invoiceId,
          type: "ACCREC" as never,
          contact: { contactID: data.contactId },
          date: data.date,
          dueDate: data.dueDate,
          status: data.status as never,
          lineItems: data.lines.map((l) => ({
            description: l.description,
            quantity: l.quantity,
            unitAmount: l.unitAmount,
            accountCode: "200",
          })),
        },
      ],
    });
    revalidatePath("/invoices");
  });
}

export async function emailInvoice(invoiceId: string) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    // Xero requires the invoice to be AUTHORISED before it can be emailed.
    // The body is intentionally an empty object — Xero uses the contact's
    // email on file.
    await xero.accountingApi.emailInvoice(tenantId, invoiceId, {});
    revalidatePath("/invoices");
  });
}

export async function markInvoicePaid(
  invoiceId: string,
  accountId: string,
  amount: number,
  date: string
) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    await xero.accountingApi.createPayment(tenantId, {
      invoice: { invoiceID: invoiceId },
      account: { accountID: accountId },
      amount,
      date,
    });
    revalidatePath("/invoices");
    revalidatePath("/");
  });
}

export async function voidInvoice(invoiceId: string) {
  return withXeroErrors(async () => {
    const { xero, tenantId } = await getXeroForRequest();
    const current = await xero.accountingApi.getInvoice(tenantId, invoiceId);
    const rawStatus = current.body.invoices?.[0]?.status;
    const currentStatus = String(rawStatus || "").toUpperCase();
    // DRAFT/SUBMITTED -> DELETED. AUTHORISED -> VOIDED. Fall back if Xero rejects.
    const deletable =
      currentStatus === "DRAFT" || currentStatus === "SUBMITTED";
    const newStatus = deletable ? "DELETED" : "VOIDED";

    try {
      await xero.accountingApi.updateInvoice(tenantId, invoiceId, {
        invoices: [{ invoiceID: invoiceId, status: newStatus as never }],
      });
    } catch (err) {
      const e = err as { response?: { body?: unknown }; body?: unknown };
      const body = e?.response?.body || e?.body;
      const msg = JSON.stringify(body || "");
      if (msg.includes("not of valid status")) {
        const fallback = newStatus === "DELETED" ? "VOIDED" : "DELETED";
        await xero.accountingApi.updateInvoice(tenantId, invoiceId, {
          invoices: [{ invoiceID: invoiceId, status: fallback as never }],
        });
      } else {
        throw err;
      }
    }
    revalidatePath("/invoices");
    revalidatePath("/");
  });
}
