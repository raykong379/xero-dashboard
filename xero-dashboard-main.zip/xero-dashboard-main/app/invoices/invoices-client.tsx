"use client";

import { useState, useTransition } from "react";
import {
  CheckCircle2,
  FileText,
  Mail,
  MessageCircle,
  Plus,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
  createInvoice,
  emailInvoice,
  getInvoiceForEdit,
  markInvoicePaid,
  updateInvoice,
  voidInvoice,
} from "./actions";

export interface InvoiceLineItem {
  description?: string;
  quantity?: number;
  unitAmount?: number;
}

export interface InvoiceRow {
  invoiceID: string;
  invoiceNumber?: string;
  status?: string;
  date?: string;
  dueDate?: string;
  total?: number;
  amountDue?: number;
  currencyCode?: string;
  contact?: { contactID?: string; name?: string; phone?: string };
  lineItems?: InvoiceLineItem[];
}

export interface ContactOption {
  contactID: string;
  name: string;
}

export interface BankAccountOption {
  accountID: string;
  name: string;
}

const STATUS_VARIANT: Record<string, React.ComponentProps<typeof Badge>["variant"]> = {
  DRAFT: "muted",
  SUBMITTED: "warning",
  AUTHORISED: "info",
  PAID: "success",
  VOIDED: "danger",
  DELETED: "danger",
};

export function InvoicesClient({
  invoices,
  contacts,
  bankAccounts,
  baseCurrency,
}: {
  invoices: InvoiceRow[];
  contacts: ContactOption[];
  bankAccounts: BankAccountOption[];
  baseCurrency: string;
}) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<InvoiceRow | null>(null);
  const [lines, setLines] = useState<InvoiceLineItem[]>([
    { description: "", quantity: 1, unitAmount: 0 },
  ]);
  const [contactId, setContactId] = useState("");
  const [status, setStatus] = useState("DRAFT");
  const [date, setDate] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [pending, startTransition] = useTransition();

  const lineSubtotal = lines.reduce(
    (sum, l) => sum + (Number(l.quantity) || 0) * (Number(l.unitAmount) || 0),
    0
  );

  // Mark-paid dialog state
  const [paidOpen, setPaidOpen] = useState(false);
  const [paying, setPaying] = useState<InvoiceRow | null>(null);
  const [paidAccountId, setPaidAccountId] = useState("");
  const [paidAmount, setPaidAmount] = useState("0");
  const [paidDate, setPaidDate] = useState("");

  function openMarkPaid(inv: InvoiceRow) {
    setPaying(inv);
    setPaidAccountId(bankAccounts[0]?.accountID || "");
    setPaidAmount(String(inv.amountDue ?? inv.total ?? 0));
    setPaidDate(new Date().toISOString().slice(0, 10));
    setPaidOpen(true);
  }

  function submitMarkPaid(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!paying) return;
    const inv = paying;
    startTransition(async () => {
      await markInvoicePaid(
        inv.invoiceID,
        paidAccountId,
        Number(paidAmount),
        paidDate
      );
      setPaidOpen(false);
    });
  }

  function handleEmail(inv: InvoiceRow) {
    if (!confirm(`Email invoice ${inv.invoiceNumber || ""} to the contact?`))
      return;
    startTransition(async () => {
      await emailInvoice(inv.invoiceID);
      alert("Invoice emailed.");
    });
  }

  function whatsappLink(inv: InvoiceRow) {
    // Malaysian local format ("0123456789") → international ("60123456789").
    const phone = (inv.contact?.phone || "")
      .replace(/[^\d]/g, "")
      .replace(/^0/, "60");
    const amount = inv.amountDue ?? inv.total ?? 0;
    const currency = inv.currencyCode || baseCurrency;
    const amountStr = amount
      ? ` (${formatCurrency(amount, currency)})`
      : "";
    const due = inv.dueDate ? new Date(inv.dueDate).toLocaleDateString() : "";
    const greeting = inv.contact?.name ? `Hi ${inv.contact.name},` : "Hi,";
    const message = [
      greeting,
      "",
      `Just a friendly reminder about invoice ${inv.invoiceNumber || ""}${amountStr}.`,
      due ? `Due date: ${due}.` : "",
      "",
      "Thank you!",
    ]
      .filter(Boolean)
      .join("\n");
    const text = encodeURIComponent(message);
    return phone
      ? `https://wa.me/${phone}?text=${text}`
      : `https://wa.me/?text=${text}`;
  }

  function openCreate() {
    setEditing(null);
    setContactId("");
    setStatus("DRAFT");
    setDate("");
    setDueDate("");
    setLines([{ description: "", quantity: 1, unitAmount: 0 }]);
    setOpen(true);
  }

  function openEdit(inv: InvoiceRow) {
    // Pre-populate from list data so the dialog opens instantly with what
    // we already know. We then refresh from the single-invoice endpoint to
    // pick up line items the list response may omit.
    setEditing(inv);
    setContactId(inv.contact?.contactID || "");
    setStatus(inv.status || "DRAFT");
    setDate(inv.date ? inv.date.slice(0, 10) : "");
    setDueDate(inv.dueDate ? inv.dueDate.slice(0, 10) : "");
    const initial = (inv.lineItems || []).map((li) => ({
      description: li.description || "",
      quantity: li.quantity ?? 1,
      unitAmount: li.unitAmount ?? 0,
    }));
    setLines(
      initial.length
        ? initial
        : [{ description: "", quantity: 1, unitAmount: 0 }]
    );
    setOpen(true);

    startTransition(async () => {
      const fresh = await getInvoiceForEdit(inv.invoiceID);
      setEditing({ ...inv, ...fresh });
      if (fresh.contact?.contactID) setContactId(fresh.contact.contactID);
      if (fresh.status) setStatus(fresh.status);
      if (fresh.date) setDate(fresh.date);
      if (fresh.dueDate) setDueDate(fresh.dueDate);
      const refreshed = (fresh.lineItems || []).map((li) => ({
        description: li.description || "",
        quantity: li.quantity ?? 1,
        unitAmount: li.unitAmount ?? 0,
      }));
      if (refreshed.length) setLines(refreshed);
    });
  }

  function addLine() {
    setLines((ls) => [...ls, { description: "", quantity: 1, unitAmount: 0 }]);
  }

  function updateLine(i: number, patch: Partial<InvoiceLineItem>) {
    setLines((ls) => ls.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  }

  function removeLine(i: number) {
    setLines((ls) => (ls.length > 1 ? ls.filter((_, idx) => idx !== i) : ls));
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    fd.set("contactId", contactId);
    fd.set("status", status);
    fd.set("date", date);
    fd.set("dueDate", dueDate);
    fd.delete("lineDescription");
    fd.delete("lineQuantity");
    fd.delete("lineUnitAmount");
    for (const l of lines) {
      fd.append("lineDescription", l.description ?? "");
      fd.append("lineQuantity", String(l.quantity ?? 1));
      fd.append("lineUnitAmount", String(l.unitAmount ?? 0));
    }
    startTransition(async () => {
      if (editing) {
        await updateInvoice(editing.invoiceID, fd);
      } else {
        await createInvoice(fd);
      }
      setOpen(false);
    });
  }

  function handleVoid(inv: InvoiceRow) {
    const verb = inv.status === "AUTHORISED" ? "Void" : "Delete";
    if (!confirm(`${verb} this invoice?`)) return;
    startTransition(async () => {
      await voidInvoice(inv.invoiceID);
    });
  }

  return (
    <>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Invoices</h1>
          <p className="mt-1 text-sm text-slate-500">
            Create, edit and void sales invoices.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> New Invoice
        </Button>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Due</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="py-6 text-center text-slate-400"
                >
                  No invoices.
                </TableCell>
              </TableRow>
            ) : (
              invoices.map((inv) => (
                <TableRow key={inv.invoiceID}>
                  <TableCell className="font-medium text-slate-800">
                    {inv.invoiceNumber || inv.invoiceID.slice(0, 8)}
                  </TableCell>
                  <TableCell>{inv.contact?.name || "—"}</TableCell>
                  <TableCell>{formatDate(inv.date)}</TableCell>
                  <TableCell>{formatDate(inv.dueDate)}</TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(
                      inv.total || 0,
                      inv.currencyCode || baseCurrency
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {inv.status ? (
                      <Badge
                        variant={STATUS_VARIANT[inv.status] || "muted"}
                      >
                        {inv.status}
                      </Badge>
                    ) : null}
                  </TableCell>
                  <TableCell className="space-x-3 text-right">
                    <button
                      type="button"
                      onClick={() => openEdit(inv)}
                      className="text-sm text-xero hover:underline"
                      disabled={pending}
                    >
                      Edit
                    </button>
                    <a
                      href={`/api/invoices/${inv.invoiceID}/pdf`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-sm text-slate-600 hover:underline"
                      title="Open PDF"
                    >
                      <FileText className="h-3.5 w-3.5" /> PDF
                    </a>
                    {inv.status === "AUTHORISED" ? (
                      <>
                        <button
                          type="button"
                          onClick={() => openMarkPaid(inv)}
                          className="inline-flex items-center gap-1 text-sm text-emerald-700 hover:underline disabled:opacity-50"
                          disabled={pending}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" /> Mark Paid
                        </button>
                        <a
                          href={whatsappLink(inv)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-sm text-emerald-600 hover:underline"
                          title={
                            inv.contact?.phone
                              ? `Send reminder to ${inv.contact.phone}`
                              : "Open WhatsApp with prefilled reminder"
                          }
                        >
                          <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
                        </a>
                        <button
                          type="button"
                          onClick={() => handleEmail(inv)}
                          className="inline-flex items-center gap-1 text-sm text-slate-600 hover:underline disabled:opacity-50"
                          disabled={pending}
                        >
                          <Mail className="h-3.5 w-3.5" /> Email
                        </button>
                      </>
                    ) : null}
                    {inv.status === "DRAFT" || inv.status === "SUBMITTED" ? (
                      <button
                        type="button"
                        onClick={() => handleVoid(inv)}
                        className="text-sm text-red-600 hover:underline disabled:opacity-50"
                        disabled={pending}
                      >
                        Delete
                      </button>
                    ) : inv.status === "AUTHORISED" ? (
                      <button
                        type="button"
                        onClick={() => handleVoid(inv)}
                        className="text-sm text-red-600 hover:underline disabled:opacity-50"
                        disabled={pending}
                      >
                        Void
                      </button>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editing
                ? `Edit invoice ${editing.invoiceNumber || ""}`
                : "New invoice"}
            </DialogTitle>
            <p className="text-sm text-slate-500">
              {editing
                ? "Update the details and save."
                : "Bill a customer for goods or services."}
            </p>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="contact">
                Bill to <span className="text-red-500">*</span>
              </Label>
              <Select value={contactId} onValueChange={setContactId} required>
                <SelectTrigger id="contact">
                  <SelectValue placeholder="Choose a customer..." />
                </SelectTrigger>
                <SelectContent>
                  {contacts.map((c) => (
                    <SelectItem key={c.contactID} value={c.contactID}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="date">
                  Issue date <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
                <p className="text-xs text-slate-500">When the invoice is issued.</p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="dueDate">
                  Due date <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  required
                />
                <p className="text-xs text-slate-500">When payment is expected.</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline justify-between">
                <Label>What are you billing for?</Label>
                <span className="text-xs text-slate-500">
                  Subtotal:{" "}
                  <span className="font-semibold tabular-nums text-slate-700">
                    {formatCurrency(lineSubtotal, baseCurrency)}
                  </span>
                </span>
              </div>
              <div className="grid grid-cols-12 gap-2 px-1 text-xs font-medium uppercase tracking-wider text-slate-500">
                <div className="col-span-7">Description</div>
                <div className="col-span-2 text-center">Qty</div>
                <div className="col-span-2 text-right">Unit price ({baseCurrency})</div>
                <div className="col-span-1" />
              </div>
              {lines.map((line, i) => (
                <div
                  key={i}
                  className="grid grid-cols-12 items-center gap-2"
                >
                  <Input
                    className="col-span-7"
                    placeholder="e.g. Consulting fee"
                    value={line.description ?? ""}
                    onChange={(e) =>
                      updateLine(i, { description: e.target.value })
                    }
                    required
                  />
                  <Input
                    className="col-span-2 text-center"
                    type="number"
                    step="1"
                    min="1"
                    placeholder="1"
                    value={line.quantity ?? 1}
                    onChange={(e) =>
                      updateLine(i, { quantity: Number(e.target.value) })
                    }
                    required
                  />
                  <Input
                    className="col-span-2 text-right"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={line.unitAmount ? line.unitAmount : ""}
                    onChange={(e) =>
                      updateLine(i, {
                        unitAmount: e.target.value === "" ? 0 : Number(e.target.value),
                      })
                    }
                    required
                  />
                  <button
                    type="button"
                    onClick={() => removeLine(i)}
                    className="col-span-1 inline-flex items-center justify-center text-slate-400 hover:text-red-600 disabled:opacity-30"
                    disabled={lines.length <= 1}
                    aria-label="Remove line"
                    title={lines.length <= 1 ? "At least one line required" : "Remove this line"}
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={addLine}
                className="mt-1 inline-flex items-center gap-1 text-sm font-medium text-xero hover:underline"
              >
                <Plus className="h-3.5 w-3.5" /> Add another line
              </button>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="status">Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DRAFT">Draft</SelectItem>
                  <SelectItem value="AUTHORISED">Authorised</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                <strong>Draft</strong> saves for later editing.{" "}
                <strong>Authorised</strong> is ready to send to your customer.
              </p>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setOpen(false)}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={pending}>
                {pending
                  ? "Saving..."
                  : editing
                    ? "Save changes"
                    : "Create invoice"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={paidOpen} onOpenChange={setPaidOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Record payment for {paying?.invoiceNumber || "invoice"}
            </DialogTitle>
            <p className="text-sm text-slate-500">
              Money received? Tell us where it landed and we&apos;ll mark this
              invoice paid.
            </p>
          </DialogHeader>
          <form onSubmit={submitMarkPaid} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="paid-account">
                Which account did the money go into?{" "}
                <span className="text-red-500">*</span>
              </Label>
              <Select
                value={paidAccountId}
                onValueChange={setPaidAccountId}
                required
              >
                <SelectTrigger id="paid-account">
                  <SelectValue placeholder="Choose a bank account..." />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((a) => (
                    <SelectItem key={a.accountID} value={a.accountID}>
                      {a.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="paid-amount">
                  Amount received <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="paid-amount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={Number(paidAmount) ? paidAmount : ""}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  required
                />
                <p className="text-xs text-slate-500">
                  Pre-filled with the amount due. Adjust for partial payments.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="paid-date">
                  Date received <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="paid-date"
                  type="date"
                  value={paidDate}
                  onChange={(e) => setPaidDate(e.target.value)}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setPaidOpen(false)}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={pending || !paidAccountId}>
                {pending ? "Recording..." : "Record payment"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
