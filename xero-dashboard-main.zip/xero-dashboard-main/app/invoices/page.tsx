import { getXeroForRequest } from "@/lib/xero";
import { toIsoDate } from "@/lib/utils";
import { AutoSubmitSelect } from "@/components/auto-submit-select";
import {
  InvoicesClient,
  type InvoiceRow,
  type ContactOption,
} from "./invoices-client";

export const dynamic = "force-dynamic";

const STATUSES = ["DRAFT", "SUBMITTED", "AUTHORISED", "PAID", "VOIDED"] as const;

export default async function InvoicesPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;
  const { xero, tenantId, baseCurrency } = await getXeroForRequest();
  const where = status ? `Status=="${status}"` : undefined;
  const [invRes, contactRes, acctRes] = await Promise.all([
    xero.accountingApi.getInvoices(tenantId, undefined, where, "Date DESC"),
    xero.accountingApi.getContacts(tenantId),
    xero.accountingApi.getAccounts(tenantId, undefined, 'Type=="BANK"'),
  ]);

  // Build a contactID → phone map so each invoice row can know its
  // recipient's phone number for the WhatsApp send action.
  const phoneByContact = new Map<string, string>();
  for (const c of contactRes.body.contacts || []) {
    if (!c.contactID) continue;
    const phone = (c.phones || []).find((p) => p.phoneNumber);
    if (phone?.phoneNumber) phoneByContact.set(c.contactID, phone.phoneNumber);
  }

  const invoices: InvoiceRow[] = (invRes.body.invoices || []).map((inv) => ({
    invoiceID: inv.invoiceID || "",
    invoiceNumber: inv.invoiceNumber,
    status: inv.status as string | undefined,
    date: toIsoDate(inv.date),
    dueDate: toIsoDate(inv.dueDate),
    total: inv.total,
    amountDue: inv.amountDue,
    currencyCode: inv.currencyCode as string | undefined,
    contact: inv.contact
      ? {
          contactID: inv.contact.contactID,
          name: inv.contact.name,
          phone: inv.contact.contactID
            ? phoneByContact.get(inv.contact.contactID)
            : undefined,
        }
      : undefined,
    lineItems: (inv.lineItems || []).map((li) => ({
      description: li.description,
      quantity: li.quantity,
      unitAmount: li.unitAmount,
    })),
  }));
  const contacts: ContactOption[] = (contactRes.body.contacts || [])
    .filter((c) => c.contactID && c.name)
    .map((c) => ({ contactID: c.contactID!, name: c.name! }));
  const bankAccounts = (acctRes.body.accounts || [])
    .filter((a) => a.accountID && a.name)
    .map((a) => ({ accountID: a.accountID!, name: a.name! }));

  return (
    <>
      <div className="mb-4 flex items-center gap-2 text-sm">
        <label htmlFor="status-filter" className="text-slate-500">
          Status:
        </label>
        <AutoSubmitSelect
          id="status-filter"
          name="status"
          defaultValue={status || ""}
          options={[
            { value: "", label: "All" },
            ...STATUSES.map((s) => ({ value: s, label: s })),
          ]}
        />
      </div>
      <InvoicesClient
        invoices={invoices}
        contacts={contacts}
        bankAccounts={bankAccounts}
        baseCurrency={baseCurrency}
      />
    </>
  );
}
