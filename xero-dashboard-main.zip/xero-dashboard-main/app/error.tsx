"use client";

import Link from "next/link";

export default function ErrorPage({
  error,
}: {
  error: Error & { digest?: string };
}) {
  return (
    <div className="max-w-xl">
      <h1 className="mb-2 text-2xl font-semibold text-slate-900">
        Something went wrong
      </h1>
      <p className="mb-4 text-slate-600">
        The server returned an error handling your request.
      </p>
      <pre className="whitespace-pre-wrap rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">
        {error.message}
      </pre>
      <Link
        href="/"
        className="mt-4 inline-block text-xero hover:underline"
      >
        ← Back to Dashboard
      </Link>
    </div>
  );
}
