import Link from "next/link";
import { getXeroForRequest } from "@/lib/xero";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

type ReportType = "pnl" | "balance" | "trial";

interface ReportRow {
  rowType?: string;
  title?: string;
  cells?: Array<{ value?: string }>;
  rows?: ReportRow[];
}

interface XeroReport {
  reportName?: string;
  reportTitles?: string[];
  rows?: ReportRow[];
}

function defaultFrom() {
  const d = new Date();
  d.setMonth(d.getMonth() - 3);
  return d.toISOString().slice(0, 10);
}
function defaultTo() {
  return new Date().toISOString().slice(0, 10);
}

async function loadReport(
  type: ReportType,
  from: string,
  to: string
): Promise<XeroReport | null> {
  const { xero, tenantId } = await getXeroForRequest();
  if (type === "pnl") {
    const r = await xero.accountingApi.getReportProfitAndLoss(
      tenantId,
      from,
      to
    );
    return (r.body.reports?.[0] as XeroReport) || null;
  }
  if (type === "balance") {
    const r = await xero.accountingApi.getReportBalanceSheet(tenantId);
    return (r.body.reports?.[0] as XeroReport) || null;
  }
  const r = await xero.accountingApi.getReportTrialBalance(tenantId);
  return (r.body.reports?.[0] as XeroReport) || null;
}

const TABS: Array<{ key: ReportType; label: string }> = [
  { key: "pnl", label: "Profit & Loss" },
  { key: "balance", label: "Balance Sheet" },
  { key: "trial", label: "Trial Balance" },
];

/**
 * Xero formats negative numbers in two ways depending on report:
 *   "-1,234.56"  or  "(1,234.56)"
 * Both should be highlighted red.
 */
function isNegative(value: string) {
  const v = value.trim();
  if (!v) return false;
  if (v.startsWith("-")) return true;
  if (v.startsWith("(") && v.endsWith(")")) return true;
  return false;
}

function isNumeric(value: string) {
  if (!value) return false;
  // Strip parens, commas, currency symbols, spaces, then test
  const cleaned = value.replace(/[(),\s$£€¥A-Za-z]/g, "");
  return cleaned !== "" && !Number.isNaN(parseFloat(cleaned));
}

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string; from?: string; to?: string }>;
}) {
  const sp = await searchParams;
  const type: ReportType =
    sp.type === "balance" || sp.type === "trial" ? sp.type : "pnl";
  const from = sp.from || defaultFrom();
  const to = sp.to || defaultTo();
  const report = await loadReport(type, from, to);

  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-slate-900">Reports</h1>
        <p className="mt-1 text-sm text-slate-600">
          Read-only financial reports.
        </p>
      </div>

      <div className="mb-4 flex gap-2 text-sm">
        {TABS.map((tab) => (
          <Link
            key={tab.key}
            href={`/reports?type=${tab.key}`}
            className={cn(
              "rounded-md px-4 py-2 font-medium transition-colors",
              type === tab.key
                ? "bg-xero text-white shadow-sm"
                : "border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-400"
            )}
          >
            {tab.label}
          </Link>
        ))}
      </div>

      {type === "pnl" ? (
        <form className="mb-4 flex items-center gap-2 text-sm">
          <input type="hidden" name="type" value="pnl" />
          <label htmlFor="from" className="font-medium text-slate-700">
            From
          </label>
          <Input
            type="date"
            id="from"
            name="from"
            defaultValue={from}
            className="w-auto"
          />
          <label htmlFor="to" className="font-medium text-slate-700">
            To
          </label>
          <Input
            type="date"
            id="to"
            name="to"
            defaultValue={to}
            className="w-auto"
          />
          <Button type="submit" variant="secondary">
            Apply
          </Button>
        </form>
      ) : null}

      {!report ? (
        <div className="rounded-lg border border-slate-200 bg-white p-6 text-slate-700">
          No report data.
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
          <div className="border-b-2 border-slate-200 bg-slate-50 px-6 py-4">
            <h2 className="text-base font-bold text-slate-900">
              {report.reportName}
            </h2>
            <div className="mt-0.5 text-sm text-slate-700">
              {(report.reportTitles || []).join(" · ")}
            </div>
          </div>
          {(report.rows || []).map((section, sectionIdx) => {
            if (section.rowType === "Header") {
              return (
                <table
                  key={sectionIdx}
                  className="w-full border-b border-slate-200 text-xs font-semibold uppercase tracking-wide"
                >
                  <thead className="bg-slate-100">
                    <tr>
                      {(section.cells || []).map((cell, i) => (
                        <th
                          key={i}
                          className={cn(
                            "px-6 py-3 text-slate-700",
                            i === 0 ? "text-left" : "text-right"
                          )}
                        >
                          {cell.value || ""}
                        </th>
                      ))}
                    </tr>
                  </thead>
                </table>
              );
            }
            if (section.rowType === "Section") {
              return (
                <div key={sectionIdx} className="border-t border-slate-200">
                  {section.title ? (
                    <div className="border-l-2 border-xero bg-slate-50 px-6 py-2.5 text-sm font-bold text-slate-900">
                      {section.title}
                    </div>
                  ) : null}
                  <table className="w-full text-sm">
                    <tbody>
                      {(section.rows || []).map((row, rowIdx) => {
                        const isSummary = row.rowType === "SummaryRow";
                        return (
                          <tr
                            key={rowIdx}
                            className={cn(
                              "border-t border-slate-200",
                              isSummary
                                ? "border-t-2 border-slate-300 bg-slate-50 font-bold"
                                : "hover:bg-slate-50"
                            )}
                          >
                            {(row.cells || []).map((cell, i) => {
                              const value = cell.value || "";
                              const numeric = isNumeric(value);
                              const negative = numeric && isNegative(value);
                              return (
                                <td
                                  key={i}
                                  className={cn(
                                    "px-6 py-2.5",
                                    i === 0
                                      ? "text-slate-900"
                                      : "text-right tabular-nums",
                                    !isSummary && i !== 0 && "text-slate-800",
                                    isSummary && "text-slate-900",
                                    negative && "text-red-700"
                                  )}
                                >
                                  {value}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              );
            }
            return null;
          })}
        </div>
      )}
    </>
  );
}
