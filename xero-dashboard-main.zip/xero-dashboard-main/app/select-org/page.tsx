import { redirect } from "next/navigation";
import { Building2, Check } from "lucide-react";
import { getSession } from "@/lib/session";
import { selectOrg } from "./actions";

export const dynamic = "force-dynamic";

export default async function SelectOrgPage() {
  const session = await getSession();

  if (!session.access_token) {
    redirect("/api/auth/login");
  }

  const tenants = session.tenants || [];
  if (tenants.length === 0) {
    redirect("/api/auth/login");
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
        <div className="text-xs uppercase tracking-wider text-slate-400">
          Xero
        </div>
        <h1 className="mt-1 text-2xl font-semibold text-slate-900">
          Choose an organisation
        </h1>
        <p className="mt-2 text-sm text-slate-500">
          You have access to multiple Xero organisations. Pick which one you
          want to view.
        </p>

        <div className="mt-6 space-y-2">
          {tenants.map((t) => {
            const active = session.tenantId === t.id;
            return (
              <form
                key={t.id}
                action={async () => {
                  "use server";
                  await selectOrg(t.id);
                }}
              >
                <button
                  type="submit"
                  className={`flex w-full items-center gap-3 rounded-md border px-4 py-3 text-left transition-colors ${
                    active
                      ? "border-xero/40 bg-xero/5"
                      : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-xero/10 text-xero">
                    <Building2 className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-slate-900">{t.name}</div>
                    <div className="text-xs text-slate-500">{t.id}</div>
                  </div>
                  {active ? (
                    <Check className="h-4 w-4 text-xero" />
                  ) : null}
                </button>
              </form>
            );
          })}
        </div>
      </div>
    </div>
  );
}
