"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getSession } from "@/lib/session";
import { createXeroClient } from "@/lib/xero";

export async function selectOrg(tenantId: string) {
  const session = await getSession();

  if (!session.access_token) {
    redirect("/api/auth/login");
  }

  const match = (session.tenants || []).find((t) => t.id === tenantId);
  if (!match) {
    throw new Error("Selected organisation is not connected to this session.");
  }

  session.tenantId = match.id;
  session.tenantName = match.name;

  // Re-pull base currency for the newly-selected org so RM/USD/GBP swaps
  // automatically when the user toggles between Sdn Bhds.
  try {
    const xero = createXeroClient();
    await xero.setTokenSet({
      access_token: session.access_token,
      refresh_token: session.refresh_token,
      expires_at: session.expires_at,
    });
    const orgRes = await xero.accountingApi.getOrganisations(match.id);
    const org = orgRes.body.organisations?.[0];
    session.baseCurrency = org?.baseCurrency as unknown as string | undefined;
    session.countryCode = org?.countryCode as unknown as string | undefined;
  } catch {
    session.baseCurrency = undefined;
    session.countryCode = undefined;
  }

  await session.save();
  revalidatePath("/", "layout");
  redirect("/");
}
