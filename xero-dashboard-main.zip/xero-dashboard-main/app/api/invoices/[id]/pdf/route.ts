import { type NextRequest, NextResponse } from "next/server";
import { getXeroForRequest } from "@/lib/xero";

/**
 * Streams the Xero-generated PDF for an invoice. The SDK returns a Buffer or
 * Readable stream depending on options; we just hand the bytes through with
 * the right Content-Type so the browser opens it inline.
 */
export async function GET(
  _req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  const { id } = await ctx.params;
  const { xero, tenantId } = await getXeroForRequest();
  const result = await xero.accountingApi.getInvoiceAsPdf(tenantId, id);
  // xero-node returns a Buffer (Node) for binary endpoints. Type any-cast
  // because the generated types aren't precise about the body shape.
  const body = (result as unknown as { body: Buffer | string }).body;
  const bytes =
    typeof body === "string" ? Buffer.from(body, "binary") : body;
  return new NextResponse(new Uint8Array(bytes), {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="invoice-${id}.pdf"`,
      "Cache-Control": "private, no-cache",
    },
  });
}
