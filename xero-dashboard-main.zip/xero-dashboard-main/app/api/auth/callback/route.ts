import { NextResponse, type NextRequest } from "next/server";
import { createXeroClient } from "@/lib/xero";
import { getSession } from "@/lib/session";

async function loadOrgCurrency(
  xero: ReturnType<typeof createXeroClient>,
  tenantId: string
) {
  try {
    const orgRes = await xero.accountingApi.getOrganisations(tenantId);
    const org = orgRes.body.organisations?.[0];
    return {
      baseCurrency: org?.baseCurrency as unknown as string | undefined,
      countryCode: org?.countryCode as unknown as string | undefined,
    };
  } catch {
    return { baseCurrency: undefined, countryCode: undefined };
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession();
  const xero = createXeroClient(session.oauthState);

  const callbackUrl = `${req.nextUrl.pathname}${req.nextUrl.search}`;
  const tokenSet = await xero.apiCallback(callbackUrl);

  session.access_token = tokenSet.access_token;
  session.refresh_token = tokenSet.refresh_token;
  session.expires_at = tokenSet.expires_at;
  session.oauthState = undefined;

  await xero.updateTenants(false);
  const tenants = xero.tenants || [];
  session.tenants = tenants.map((t) => ({
    id: t.tenantId,
    name: t.tenantName,
  }));

  if (tenants.length === 0) {
    await session.save();
    throw new Error(
      "No Xero organisations are connected to this account."
    );
  }

  if (tenants.length === 1) {
    // Only one org connected — auto-select it.
    const tenantId: string = tenants[0].tenantId;
    session.tenantId = tenantId;
    session.tenantName = tenants[0].tenantName;
    const { baseCurrency, countryCode } = await loadOrgCurrency(
      xero,
      tenantId
    );
    session.baseCurrency = baseCurrency;
    session.countryCode = countryCode;
    await session.save();
    return NextResponse.redirect(new URL("/", req.url));
  }

  // Multiple orgs connected — let the user choose which one to use.
  await session.save();
  return NextResponse.redirect(new URL("/select-org", req.url));
}
