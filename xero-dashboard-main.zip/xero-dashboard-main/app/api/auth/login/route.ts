import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { createXeroClient } from "@/lib/xero";
import { getSession } from "@/lib/session";

export async function GET() {
  // Generate a CSRF state ourselves and persist it in the session so the
  // /callback route can recreate a XeroClient with the same state — required
  // for openid-client to validate the round-trip on serverless cold-starts.
  const state = randomUUID();
  const xero = createXeroClient(state);
  const consentUrl = await xero.buildConsentUrl();
  const session = await getSession();
  session.oauthState = state;
  await session.save();
  return NextResponse.redirect(consentUrl);
}
