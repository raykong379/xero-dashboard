# PRD.md — Xero Accounting Dashboard

## Project Overview

Build a web-based accounting dashboard that connects to Xero's API, displays real financial data from the Demo Company, and supports full CRUD operations across key accounting modules. This is an internal tool / proof-of-concept for demonstrating Xero API integration.

---

## Goals

- Authenticate with Xero via OAuth 2.0 and maintain token sessions
- Display live data from Xero Demo Company across 4 modules
- Allow Create, Read, Update, Delete operations via the UI
- Clean, professional dashboard UI using Tailwind CSS

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js (v18+) |
| Backend framework | Express.js |
| Xero integration | `xero-node` SDK (official) |
| Frontend styling | Tailwind CSS via CDN |
| Templating | EJS (server-side rendered HTML) |
| Auth | OAuth 2.0 via xero-node |
| Token storage | In-memory (dev) / `.env` for credentials |
| Dev environment | localhost:3000 |

---

## Project Structure

```
xero-dashboard/
├── .env                   # XERO_CLIENT_ID, XERO_CLIENT_SECRET, REDIRECT_URI
├── package.json
├── server.js              # Express app entry point
├── routes/
│   ├── auth.js            # OAuth login/callback/logout
│   ├── invoices.js        # Invoices CRUD routes
│   ├── contacts.js        # Contacts CRUD routes
│   ├── transactions.js    # Bank Transactions routes
│   └── reports.js         # Reports (read-only) routes
├── views/
│   ├── layout.ejs         # Shared layout with sidebar nav
│   ├── index.ejs          # Dashboard home / summary
│   ├── invoices.ejs       # Invoices list + form
│   ├── contacts.ejs       # Contacts list + form
│   ├── transactions.ejs   # Bank transactions list
│   └── reports.ejs        # P&L / Balance Sheet display
└── public/
    └── (static assets if any)
```

---

## Authentication Flow

1. User visits `localhost:3000` → redirected to `/auth/login` if not authenticated
2. `/auth/login` → generates Xero OAuth URL → redirects user to Xero login
3. User logs in at Xero → Xero redirects to `/auth/callback?code=...`
4. Server exchanges code for `access_token` + `refresh_token` → stores in session
5. All subsequent API calls use the stored token; auto-refresh before expiry (30min window)
6. `/auth/logout` clears session

### Required OAuth Scopes
```
openid profile email offline_access
accounting.transactions
accounting.contacts
accounting.reports.read
accounting.settings
```

### Environment Variables (.env)
```
XERO_CLIENT_ID=your_client_id_here
XERO_CLIENT_SECRET=your_client_secret_here
REDIRECT_URI=http://localhost:3000/auth/callback
SESSION_SECRET=any_random_string
```

---

## Modules & Features

### 1. Dashboard Home (`/`)
- Summary cards: Total Outstanding Invoices, Total Contacts, Recent Transactions count
- Quick links to each module
- Shows connected Xero organisation name

### 2. Invoices (`/invoices`)

| Operation | HTTP | Xero API Endpoint | UI Action |
|-----------|------|-------------------|-----------|
| List all invoices | GET | `GET /Invoices` | Table with status filter (DRAFT/AUTHORISED/PAID) |
| View single invoice | GET | `GET /Invoices/{InvoiceID}` | Click row to expand details |
| Create invoice | POST | `POST /Invoices` | "New Invoice" button → modal form |
| Update invoice | PUT | `PUT /Invoices/{InvoiceID}` | Edit button on row |
| Delete / void invoice | POST | `POST /Invoices/{InvoiceID}` (set status=VOIDED) | Delete button (only DRAFT invoices) |

Form fields for Create/Update:
- Contact (dropdown from Contacts list)
- Invoice date, due date
- Line items: description, quantity, unit price
- Status: DRAFT or AUTHORISED

### 3. Contacts (`/contacts`)

| Operation | HTTP | Xero API Endpoint | UI Action |
|-----------|------|-------------------|-----------|
| List all contacts | GET | `GET /Contacts` | Searchable table |
| View contact | GET | `GET /Contacts/{ContactID}` | Click row |
| Create contact | POST | `POST /Contacts` | "New Contact" modal |
| Update contact | PUT | `PUT /Contacts/{ContactID}` | Edit button |
| Archive contact | POST | `POST /Contacts/{ContactID}` (IsArchived=true) | Archive button |

Form fields:
- Name (required)
- Email, phone
- Is customer / Is supplier toggle

### 4. Bank Transactions (`/transactions`)

| Operation | HTTP | Xero API Endpoint | UI Action |
|-----------|------|-------------------|-----------|
| List transactions | GET | `GET /BankTransactions` | Table with date filter |
| View transaction | GET | `GET /BankTransactions/{BankTransactionID}` | Click row |
| Create transaction | POST | `POST /BankTransactions` | "New Transaction" modal |
| Update transaction | PUT | `PUT /BankTransactions/{BankTransactionID}` | Edit button (DRAFT only) |

Form fields:
- Bank account (from accounts list)
- Type: SPEND or RECEIVE
- Date, amount, description, contact

### 5. Reports (`/reports`)

Read-only. No create/update/delete.

| Report | Xero API Endpoint |
|--------|-------------------|
| Profit & Loss | `GET /Reports/ProfitAndLoss` |
| Balance Sheet | `GET /Reports/BalanceSheet` |
| Trial Balance | `GET /Reports/TrialBalance` |

Display as formatted tables. Include date range filter for P&L.

---

## UI Design Specs

- **Theme**: Light mode, clean and professional (suitable for client/boss presentation)
- **Layout**: Fixed left sidebar navigation + main content area
- **Sidebar items**: Dashboard, Invoices, Contacts, Transactions, Reports, Logout
- **Typography**: Clear hierarchy — page title, table headers, data cells
- **Colors**: Neutral base (white/light grey), Xero brand blue (`#13B5EA`) as accent
- **Tables**: Striped rows, hover highlight, status badges (color-coded by status)
- **Forms**: Modal overlay for Create/Edit, inline validation messages
- **Loading states**: Show spinner while fetching API data
- **Error states**: Display friendly error message if API call fails

---

## Setup Instructions (for developer)

### Step 1: Create Xero Developer App
1. Go to https://developer.xero.com/app/manage/
2. Click "New App"
3. App name: `Xero Dashboard Dev`
4. Redirect URI: `http://localhost:3000/auth/callback`
5. Copy Client ID and Client Secret

### Step 2: Set Up Xero Demo Company
1. Log in to https://go.xero.com
2. Click your org name (top left) → "Add Organisation" → "Try a demo company"
3. This creates a pre-filled Demo Company with mock invoices, contacts, transactions

### Step 3: Local Dev Setup
```bash
mkdir xero-dashboard
cd xero-dashboard
npm init -y
npm install express xero-node dotenv ejs express-session
```

Create `.env` file with credentials from Step 1.

### Step 4: Run
```bash
node server.js
# Open http://localhost:3000
```

---

## API Rate Limits (awareness)

- Xero allows **60 API calls per minute** per organisation
- Minute limit resets every 60 seconds
- If exceeded, returns HTTP 429 — add basic retry logic or user-facing message

---

## Out of Scope (for this version)

- User authentication (no multi-user login system — single Xero org only)
- Database persistence (no Supabase/SQL for this MVP)
- Deployment to production (localhost dev only)
- Payroll API
- Webhooks / real-time sync

---

## Success Criteria

- [ ] Can log in via Xero OAuth and see Demo Company name
- [ ] Can list all invoices, contacts, transactions, reports
- [ ] Can create a new invoice and see it appear in Xero
- [ ] Can edit an existing contact
- [ ] Can create a bank transaction
- [ ] UI is clean and presentable to supervisor
